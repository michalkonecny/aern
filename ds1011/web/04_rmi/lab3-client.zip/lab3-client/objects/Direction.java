package objects;

import java.io.Serializable;

/**
 * Enumerated type for specifying a direction
 * 
 * @author ingrambr
 * 
 */
public enum Direction implements Serializable
{
    LEFT, RIGHT, UP, DOWN
}
