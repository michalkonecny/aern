package objects;

import java.awt.Color;
import java.awt.Graphics;

/**
 * Line class
 * 
 * @author ingrambr
 * 
 */
public class Line implements java.io.Serializable
{

    private static final long serialVersionUID = 430863402403237501L;
    
    private int xmin;
    private int xmax;
    private int ymin;
    private int ymax;

    /**
     * Class Constructor
     * 
     * @param x1
     *            Horizontal start position for line
     * @param y1
     *            Vertical start position for line
     * @param x2
     *            Horizontal end position for line
     * @param y2
     *            Vertical end position for line
     */
    public Line(int x1, int y1, int x2, int y2)
    {
        xmin = x1;
        ymin = y1;
        xmax = x2;
        ymax = y2;
    }

    /**
     * Draw the line
     * 
     * @param g
     *            Graphics object where line is to be drawn
     */
    public void draw(Graphics g)
    {
        g.setColor(Color.WHITE);
        g.drawLine(xmin, ymin, xmax, ymax);
    }

}
