package objects;

import java.awt.Color;
import java.awt.Graphics;

/**
 * Abstract base Shape class
 * 
 * @author ingrambr
 * 
 */

public abstract class Shape implements java.io.Serializable
{
    private int xpos;
    private int ypos;
    private Color col;

    /**
     * Class constructor
     * 
     * @param x
     *            Horizontal position of shape
     * @param y
     *            Vertical position of shape
     * @param c
     *            Colour of shape
     */
    public Shape(int x, int y, Color c)
    {
        xpos = x;
        ypos = y;
        col = c;
    }

    /**
     * Draw shape on supplied Graphics object.
     * 
     * @param g
     *            Graphics object
     */
    public void draw(Graphics g)
    {
        g.setColor(getColor());
    }

    /**
     * Get the horizontal position of the shape
     * 
     * @return Horizontal position of shape
     */
    protected int getXpos()
    {
        return xpos;
    }

    /**
     * Get the vertical position of the shape
     * 
     * @return Vertical position of shape
     */
    protected int getYpos()
    {
        return ypos;
    }

    /**
     * Get the colour of the shape
     * 
     * @return Colour of shape
     */
    private Color getColor()
    {
        return col;
    }

}
