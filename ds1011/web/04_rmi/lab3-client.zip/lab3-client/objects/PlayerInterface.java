package objects;

import java.rmi.Remote;


public interface PlayerInterface extends Remote
{
    public int getXPos() throws java.rmi.RemoteException;
    public int getYPos() throws java.rmi.RemoteException;
}
