package clients;

import java.awt.Color;
import java.rmi.*;

import objects.Circle;
import objects.Line;
import objects.Rectangle;

import server.BoardServerInterface;

public class DrawLetter
{

    public static void main(String args[])
    {
        final String serverHost = TODO;
        final String serverName = TODO;
        final String registryURI = "rmi://" + serverHost + "/" + serverName;

        System.setSecurityManager(new RMISecurityManager());

        try
        {

            BoardServerInterface server =
                TODO;
            
            TODO;
            
        }
        catch (Exception e)
        {
            System.out.println("Error while performing RMI");
            e.printStackTrace();
        }
    }
}
