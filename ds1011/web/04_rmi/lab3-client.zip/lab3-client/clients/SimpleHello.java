package clients;
import java.rmi.*; 
import server.BoardServerInterface;

public class SimpleHello 
{
	 
	public static void main(String args[])
    {
        final String serverHost = TODO;
        final String serverName = TODO;
        final String registryURI = "rmi://" + serverHost + "/" + serverName;
        String serverResponse;

        System.setSecurityManager(new RMISecurityManager());
        try
        {

            BoardServerInterface server = 
                TODO;
            serverResponse = 
                TODO;
            System.out.println(serverResponse);

        }
        catch (Exception e)
        {
            System.out.println("Error while performing RMI");
            e.printStackTrace();
        }
    }
}
