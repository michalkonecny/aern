package clients;

import java.rmi.*;

import objects.Direction;
import objects.PlayerInterface;


import server.BoardServerInterface;

public class SearchDuck
{

    public static void main(String args[])
    {
        final String serverHost = TODO;
        final String serverName = TODO;
        
        int playerNum = 4;

        System.setSecurityManager(new RMISecurityManager());

        try
        {

            BoardServerInterface server =
                TODO;
            
            // chase the duck!
            TODO;

        }
        catch (Exception e)
        {
            System.out.println("Error while performing RMI");
            e.printStackTrace();
        }
    }
}
