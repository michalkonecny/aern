package clients;

import java.awt.Color;
import java.rmi.*;

import objects.Circle;
import objects.Line;
import objects.Rectangle;

import server.BoardServerInterface;

public class DrawPic
{

    public static void main(String args[])
    {
        final String serverHost = "cs-teaching1.aston.ac.uk";
        final String serverName = "CS3250Server";
        final String registryURI = "rmi://" + serverHost + "/" + serverName;

        System.setSecurityManager(new RMISecurityManager());

        try
        {

            BoardServerInterface server =
                (BoardServerInterface) Naming.lookup(registryURI);
            
//            server.drawShape(new );
            
        }
        catch (Exception e)
        {
            System.out.println("Error while performing RMI");
            e.printStackTrace();
        }
    }
}
