package clients;

import java.rmi.*;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;

public class LookupServers
{
    public static void main(String args[])
    {

        String[] names;

        System.setSecurityManager(new RMISecurityManager());
        
        try
        {
            Registry registry =
                TODO;
            names = 
                TODO;
        }
        catch (Exception e)
        {
            System.out.println("Error while performing RMI");
            e.printStackTrace();
            return;
        }

        for (String name : names)
        {
            System.out.println(name);
        }

    }
}
