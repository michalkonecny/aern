package server;

import java.awt.Graphics;
import java.awt.Image;
import java.awt.MediaTracker;
import java.awt.Toolkit;

import javax.swing.JPanel;

import objects.*;


import java.awt.Color;
import java.awt.image.BufferedImage;
import java.rmi.RemoteException;
import java.rmi.server.RemoteServer;
import java.rmi.server.ServerNotActiveException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Random;

public class pnlPeople extends JPanel
{

    private final int xGridSize = 30;
    private final int yGridSize = 15;
    private final int squareSize = 20;

    private final Color backgroundColour = new Color(32, 96, 32);
    private final Color[] colourList =
        { Color.blue, Color.cyan, Color.orange, Color.red, Color.pink,
                Color.yellow, Color.pink, Color.gray, Color.magenta };

    private BufferedImage img;
    private Graphics gArea;
    private MediaTracker mediaTracker;
    private int xDuck = 15;
    private int yDuck = 15;
    private Image imgDuck;
    private Random generator;
    private int position;
    
    private ArrayList<Player> foreignPlayers;
    private ArrayList<Player> team;

    public pnlPeople() throws RemoteException, ServerNotActiveException
    {
        super();
        initialize();
    }

    private synchronized void initialize() throws RemoteException, ServerNotActiveException
    {
        int x, y;
        generator = new Random();
        mediaTracker = new MediaTracker(this);

        foreignPlayers = new ArrayList<Player>();

        // create an image that is the same size as field of play
        img = new BufferedImage(xGridSize * squareSize, yGridSize * squareSize,
                BufferedImage.TYPE_INT_RGB);
        gArea = img.getGraphics();

        // Load duck icon
        imgDuck = Toolkit.getDefaultToolkit().getImage("images/duck.png");
        mediaTracker.addImage(imgDuck, 0);

        team = new ArrayList<Player>(BoardServerConstants.numberOfDefaultPlayers);

        // create the player objects with random starting positions
        for (int i = 0; i < BoardServerConstants.numberOfDefaultPlayers; i++)
        {
            do
            {
                x = generator.nextInt(xGridSize);
                y = generator.nextInt(yGridSize);
            }
            while (squareOccupied(x, y));

            Player p = new Player(x, y, colourList[i % colourList.length], mediaTracker);
            
            // set the movement constraint on players:
            p.setConstraint(0, 0, xGridSize - 1, yGridSize - 1);

            team.add(p);
        }

        // create a unique starting point for the duck
        placeDuck();

        // set the position that the person found the duck
        position = 1;

        try
        {
            mediaTracker.waitForID(0);
        }
        catch (InterruptedException e)
        {
            e.printStackTrace();
        }

        updateImage();
    }

    public synchronized void placeDuck()
    {
        int x, y;
        do
        {
            x = generator.nextInt(xGridSize);
            y = generator.nextInt(yGridSize);
        }
        while (squareOccupied(x, y));
        
        xDuck = x;
        yDuck = y;
    }

    // check to see if a square on the grid is already occupied
    public synchronized boolean squareOccupied(int x, int y)
    {
        // cycle through players checking their location
        for (Player p : team)
        {
            if (p.atLocation(x, y)) { return (true); }            
        }
        
        for (Player p : foreignPlayers)
        {
            if (p.atLocation(x, y)) { return (true); }            
        }
        
        return (false);
    }
    

    public String movePlayer(int playerNumber, Direction direction)
        throws RemoteException
    {
        // check that Player exists, otherwise default to player 1.
        if ((playerNumber <= 0) || (playerNumber > BoardServerConstants.numberOfDefaultPlayers))
        {
            playerNumber = 1;
        }
        
        PlayerInterface p = team.get(playerNumber - 1);
        
        return movePlayer(p, direction);
    }

    public synchronized void updateImage()
    {
        // set background colour of Image
        gArea.setColor(backgroundColour);
        gArea.fillRect(0, 0, xGridSize * squareSize, yGridSize * squareSize);

        // draw the duck
        gArea.drawImage(imgDuck, xDuck * squareSize, yDuck * squareSize, null);

        // cycle through Players and add them to Image
        int i = 0;
        for (Player p : team)
        {
            char[] playerText = Integer.toString(i + 1).toCharArray();
            i++;

            int xPlot = p.getXPos() * squareSize;
            int yPlot = p.getYPos() * squareSize;
            gArea.drawImage(p.getPersonGraphic(), xPlot, yPlot, null);

            // if the Player is on the top line of grid, display number below
            if (yPlot == 0)
            {
                yPlot = yPlot + 30;
            }

            // print the Player number
            gArea.setColor(p.getColour());
            gArea.drawChars(playerText, 0, playerText.length, xPlot, yPlot);
        }

        // cycle through foreign Players and add them to Image
        for(Player p : foreignPlayers)
        {
            int xPlot = p.getXPos() * squareSize;
            int yPlot = p.getYPos() * squareSize;
            gArea.drawImage(p.getPersonGraphic(), xPlot, yPlot, null);

            // if the Player is on the top line of grid, display number below
            if (yPlot == 0)
            {
                yPlot = yPlot + 30;
            }

            // print the Player number
            gArea.setColor(p.getColour());
            gArea.drawString(p.getName(), xPlot, yPlot);
        }
        
        repaint();
    }

    public void paintComponent(Graphics g)
    {
        g.drawImage(img, 0, 0, null);
    }

    public synchronized PlayerInterface createPlayer(String name) 
        throws RemoteException, ServerNotActiveException
    {
        int x, y;
        
        // find a vacant space on the board:
        do
        {
            x = generator.nextInt(xGridSize);
            y = generator.nextInt(yGridSize);
        }
        while (squareOccupied(x, y));
        
        // create a new player at the vacant position:
        Player newPlayer =
            new Player(x, y, 
                        colourList[generator.nextInt(1000) % colourList.length], 
                        name);
        
        newPlayer.setConstraint(0, 0, xGridSize - 1, yGridSize - 1);
        
        // check that we don't have a player with this name already:
        for( Player p : foreignPlayers )
        {
            if (p.getName().equals(name))
            {
                if (p.getHost().equals(newPlayer.getHost())) { return p; }
            }
        }

        // register the player with the playfield: 
        foreignPlayers.add(newPlayer);
        return newPlayer;
    }

    public String movePlayer(PlayerInterface player, Direction d)
            throws RemoteException
    {
        String result;

        player.move(d);
        updateImage();

        synchronized (this)
        {
            if (player.atLocation(xDuck, yDuck))
            {
                placeDuck();
                result = "Got the duck. Congratulations! You are placed: " + position;
                position++;
            }
            else
            {
                result = "Unlucky! Try again!";
            }
        }

        return result;
    }

    public synchronized PlayerInterface getPlayer(String name) 
        throws RemoteException, ServerNotActiveException
    {

        String clientHost = RemoteServer.getClientHost();
        
        for (Player p : foreignPlayers)
        {
            if (name.equals(p.getName()))
            {
                if (p.getHost().equals(clientHost)) { return p; }
            }
        }
        
        return null;
        // if can't find it then return player 0 or null?
        // return team[0];
    }
}
