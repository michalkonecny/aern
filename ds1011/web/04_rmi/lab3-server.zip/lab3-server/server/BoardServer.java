package server;

import java.rmi.Naming;
import java.rmi.registry.LocateRegistry;
import java.rmi.RMISecurityManager;
import java.rmi.RemoteException;
import java.rmi.server.ServerNotActiveException;
import java.rmi.server.UnicastRemoteObject;
import javax.swing.SwingUtilities;

import objects.*;

/**
 * Main application class. It creates a server and a GUI.
 * 
 * @author ingrambr
 * 
 */
public class BoardServer extends UnicastRemoteObject implements
        BoardServerInterface
{

    private static BoardServer serverObject;
    private static frmMain GUI;

    /**
     * @throws RemoteException
     */
    public BoardServer() throws RemoteException
    {
        super();
    }

    public String sayHello(String s) throws RemoteException
    {
        String Message = "Hello! You sent me: " + s;
        return Message;
    }

    public void drawLine(Line l) throws RemoteException
    {
        GUI.getScribbleArea().addLine(l);
    }

    public void drawShape(Shape s) throws RemoteException
    {
        GUI.getShapesArea().addShape(s);
    }

    public String movePlayer(int n, Direction d) 
        throws RemoteException, ServerNotActiveException
    {
        String str = GUI.getPeopleArea().movePlayer(n, d);
        // GUI.getPeopleArea().updateImage();
        return str;
    }

    public void sendMessage(Message m) throws RemoteException
    {
        GUI.getTextArea().sendMessage(m);
    }

    public PlayerInterface createPlayer(String name) 
        throws RemoteException, ServerNotActiveException
    {
        PlayerInterface p = GUI.getPeopleArea().createPlayer(name);
        GUI.getPeopleArea().updateImage();
        return p;
    }

    public String movePlayer(PlayerInterface player, Direction d)
        throws RemoteException, ServerNotActiveException
    {
        String str = GUI.getPeopleArea().movePlayer(player, d);
        // GUI.getPeopleArea().updateImage();
        return str;
    }

    public PlayerInterface getPlayer(String name) 
        throws RemoteException, ServerNotActiveException
    {
        return (GUI.getPeopleArea()).getPlayer(name);
    }

    /**
     * @param args
     */
    public static void main(String[] args)
    {

        // create GUI
        SwingUtilities.invokeLater(new Runnable()
        {
            public void run()
            {
                try
                {
                    GUI = new frmMain();
                }
                catch (RemoteException e)
                {
                    e.printStackTrace();
                }
                catch (ServerNotActiveException e)
                {
                    e.printStackTrace();
                }
                GUI.setVisible(true);
            }
        });

        System.out.printf("setting security manager...");
        System.setSecurityManager(new RMISecurityManager());
        System.out.printf("ok\n");

        try
        {
            // create application
            System.out.printf("creating application...");
            serverObject = new BoardServer();
            System.out.printf("ok\n");

            // create RMI registry
            System.out.printf("creating Java RMI registry on port 1099...");
            LocateRegistry.createRegistry(1099);
            System.out.printf("ok\n");

            // bind server name to this application
            System.out.printf("rebinding...");
            Naming.rebind(BoardServerConstants.serverName, serverObject);
            System.out.printf("ok\n");
        }
        catch (Exception e)
        {
            System.out.println("An Exception occured while creating server");
            e.printStackTrace();
        }

    }


}
