package server;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.image.BufferedImage;
import javax.swing.JPanel;

import objects.*;

public class pnlShapes extends JPanel
{

    private int xSize;
    private int ySize;
    private BufferedImage img;
    private Graphics gArea;

    private static final long serialVersionUID = 1L;

    /**
     * 
     */
    public pnlShapes(int x, int y)
    {
        super();
        xSize = x;
        ySize = y;
        initialize();
    }

    /**
     * 
     */
    private void initialize()
    {
        this.setSize(300, 300);
        img = new BufferedImage(300, 300, BufferedImage.TYPE_INT_ARGB);
        gArea = img.getGraphics();
        gArea.setColor(Color.BLUE);
        gArea.fillRect(0, 0, xSize, ySize);
    }

    /**
     * @param s
     */
    public void addShape(Shape s)
    {
        s.draw(gArea);
        repaint();
    }

    /*
     * (non-Javadoc)
     * 
     * @see javax.swing.JComponent#paintComponent(java.awt.Graphics)
     */
    public void paintComponent(Graphics g)
    {
        g.drawImage(img, 0, 0, null);
    }

}
