package server;

import java.rmi.*;
import java.rmi.server.ServerNotActiveException;

import objects.*;


/**
 * @author ingrambr
 * 
 */
public interface BoardServerInterface extends Remote
{

    /**
     * sayHello is a simple method for checking that sending and receiving from
     * the server is functioning
     * 
     * @param s
     *            String of characters
     * @return a String from the server
     * @throws RemoteException
     */
    String sayHello(String s) throws RemoteException;

    /**
     * Draws a line
     * 
     * @param l
     *            A line object to be drawn
     * @throws RemoteException
     */
    void drawLine(Line l) throws RemoteException;

    /**
     * Draws a shape
     * 
     * @param s
     *            A shape object to be drawn
     * @throws RemoteException
     */
    void drawShape(Shape s) throws RemoteException;

    /**
     * Moves one of pre-defined players one step Left, Right, Up or Down
     * 
     * @param n
     *            is an integer denoting the required player
     * @param d
     *            is a direction LEFT, RIGHT, UP, DOWN
     * @return String indicating success
     * @throws RemoteException
     * @throws ServerNotActiveException
     */
    String movePlayer(int n, Direction d) 
        throws RemoteException, ServerNotActiveException;

    /**
     * Create a new Player remote object and return a remote reference to it.
     * 
     * @param name
     * @return reference to the newly created remote Player object
     * @throws RemoteException
     * @throws ServerNotActiveException
     */
    PlayerInterface createPlayer(String name) 
        throws RemoteException, ServerNotActiveException;

    /**
     * Get an existing Player remote object and return a remote reference to it.
     * 
     * @param name
     * @return reference to the newly created remote Player object
     * @throws RemoteException
     * @throws ServerNotActiveException
     */
    PlayerInterface getPlayer(String name) 
        throws RemoteException, ServerNotActiveException;

    /**
     * Moves a player one step Left, Right, Up or Down
     * 
     * @param player
     *            is a reference to a remote Player object
     * @param d
     *            is a direction LEFT, RIGHT, UP, DOWN
     * @return String indicating success
     * @throws RemoteException
     * @throws ServerNotActiveException
     */
    String movePlayer(PlayerInterface player, Direction d)
        throws RemoteException, ServerNotActiveException;

    /**
     * Sends a message string to the server
     * 
     * @param m
     *            Message object
     * @throws RemoteException
     */
    void sendMessage(Message m) throws RemoteException;

}
