package server;

import javax.swing.JPanel;
import javax.swing.JFrame;
import java.awt.Dimension;
import java.awt.Rectangle;
import java.awt.Point;
import java.rmi.RemoteException;
import java.rmi.server.ServerNotActiveException;

public class frmMain extends JFrame
{

    private JPanel jContentPane = null;
    private pnlScribble ScribbleArea = null;
    private pnlShapes ShapesArea = null;
    private pnlPeople PeopleArea = null;
    private pnlTextBox TextArea = null;

    public frmMain() throws RemoteException, ServerNotActiveException
    {
        super();
        initialize();
    }

    private void initialize() throws RemoteException, ServerNotActiveException
    {
        this.setSize(808, 629);
        this.setPreferredSize(new Dimension(800, 600));
        this.setContentPane(getJContentPane());
        this.setTitle("CS3250 - Distributed Systems");
    }

    private JPanel getJContentPane() throws RemoteException,
            ServerNotActiveException
    {
        if (jContentPane == null)
        {
            jContentPane = new JPanel();
            jContentPane.setLayout(null);
            jContentPane.setPreferredSize(new Dimension(800, 600));
            jContentPane.add(getScribbleArea(), null);
            jContentPane.add(getShapesArea(), null);
            jContentPane.add(getPeopleArea(), null);
            jContentPane.add(getTextArea(), null);
        }
        return jContentPane;
    }

    public pnlScribble getScribbleArea()
    {
        if (ScribbleArea == null)
        {
            ScribbleArea = new pnlScribble(300, 300);
            ScribbleArea.setLayout(null);
            ScribbleArea.setBounds(new Rectangle(0, 0, 300, 300));
            ScribbleArea.repaint();
        }
        return ScribbleArea;
    }

    public pnlShapes getShapesArea()
    {
        if (ShapesArea == null)
        {
            ShapesArea = new pnlShapes(300, 300);
            ShapesArea.repaint();
            ShapesArea.setBounds(new Rectangle(300, 0, 300, 300));
        }
        return ShapesArea;
    }

    public pnlPeople getPeopleArea() throws RemoteException,
            ServerNotActiveException
    {
        if (PeopleArea == null)
        {
            PeopleArea = new pnlPeople();
            PeopleArea.setSize(new Dimension(600, 300));
            PeopleArea.setLocation(new Point(0, 300));
            PeopleArea.repaint();
        }
        return PeopleArea;
    }

    public pnlTextBox getTextArea()
    {
        if (TextArea == null)
        {
            TextArea = new pnlTextBox();
            TextArea.setBounds(new Rectangle(600, 0, 200, 600));
            TextArea.repaint();
        }
        return TextArea;
    }

}
