package tests;

import java.net.MalformedURLException;
import java.rmi.Naming;
import java.rmi.NotBoundException;
import java.rmi.RemoteException;
import java.rmi.server.ServerNotActiveException;
import java.util.Random;

import objects.Direction;
import objects.PlayerInterface;
import server.BoardServerConstants;
import server.BoardServerInterface;

public class MoveManyMen
{
    private static final int numberOfMen = 100;

    private static class ManThread extends Thread
    {
        private String name;
        private PlayerInterface player;
        private BoardServerInterface server;
        private Random generator;
        
        public ManThread(int i) 
            throws RemoteException, ServerNotActiveException, 
                   MalformedURLException, NotBoundException
        {
            server = 
                (BoardServerInterface)
                Naming.lookup("rmi://" + BoardServerConstants.serverHost + "/" + BoardServerConstants.serverName);
            name = "M" + i;
            player = server.createPlayer(name);
            generator = new Random();
        }
        
        @Override
        public void run()
        {
            while ( true )
            {
                int steps = 1 + generator.nextInt(5);
                Direction d = Direction.values()[generator.nextInt(4)];
                try
                {
                    for ( int step = 0 ; step < steps; step ++)
                    {
                        String response = server.movePlayer(player, d);
                        System.out.printf("%s: %s\n", name, response);
                    }
                }
                catch (Exception e)
                {
                    e.printStackTrace();
                }
            }
        }
    }
    
    public static void main(String[] args)
    {
        // start a thread per man:
        for (int i = 0; i < numberOfMen; i++ )
        {
            try
            {
                new ManThread(i).start();
            }
            catch (Exception e)
            {
                e.printStackTrace();
            }
        }
    }
    
}
