package objects;

import java.rmi.Remote;


public interface PlayerInterface extends Remote
{
    public int getXPos() throws java.rmi.RemoteException;
    public int getYPos() throws java.rmi.RemoteException;
    
    void move(Direction d) throws java.rmi.RemoteException;

    boolean atLocation(int x, int y) throws java.rmi.RemoteException;
}
