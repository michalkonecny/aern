package objects;

import java.io.Serializable;

/**
 * Message is a class for storing a machine name and message text
 * 
 * @author ingrambr
 * 
 */
public class Message implements Serializable
{
    private static final long serialVersionUID = 453404474348443614L;
    
    private String Hostname;
    private String Message;

    /**
     * Class constructor specifying the message content
     * 
     * @param msg
     *            A string containing the message
     */
    public Message(String msg)
    {
        Hostname = getLocalHostname();
        Message = msg;
    }

    /**
     * Get hostname part of object
     * 
     * @return a String containing the hostname of the machine where the object
     *         was created
     */
    public String getHostname()
    {
        return Hostname;
    }

    /**
     * Get text part of message object
     * 
     * @return a String containing the message
     */
    public String getText()
    {
        return Message;
    }

    /**
     * Gets the hostname of the machine where the object was created
     * 
     * @return the hostname of the machine
     */
    private String getLocalHostname()
    {
        String s;
        try
        {
            java.net.InetAddress localMachine = java.net.InetAddress
                    .getLocalHost();
            s = localMachine.getHostName();
        }
        catch (Exception e)
        {
            s = "UnknownHost";
        }
        return s;
    }
}
