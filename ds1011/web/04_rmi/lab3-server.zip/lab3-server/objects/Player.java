package objects;

import java.awt.Color;
import java.awt.Image;
import java.awt.MediaTracker;
import java.awt.Toolkit;
import java.rmi.RemoteException;
import java.rmi.server.ServerNotActiveException;
import java.rmi.server.UnicastRemoteObject;

/**
 * Player class for representing a player in a game
 * 
 * @author ingrambr
 * 
 */
public class Player extends UnicastRemoteObject implements PlayerInterface
{

    private static final long serialVersionUID = -5684813679858405222L;

    private int xPos, yPos; // position of player on board
    private int xMin, yMin, xMax, yMax; // area where player movement is
                                        // constrained
    private String name;
    private String host;
    private Color uniformColour;
    private Direction currentDirection; // direction that the player is facing
    private int playerStep; // icon in sequence to use
    private static final int numberOfDirections = 4;
    private static final int numberOfFrames = 4;
    private static Image[][] icons;
    MediaTracker mediaTracker;

    /**
     * Class constructor
     * 
     * @param x
     *            Starting horizontal position
     * @param y
     *            Starting hotizontal position
     * @param c
     *            Colour of player
     * @throws ServerNotActiveException
     */
    public Player(int x, int y, Color c) throws RemoteException,
            ServerNotActiveException
    {
        xPos = x;
        yPos = y;
        uniformColour = c;
        currentDirection = Direction.LEFT;
        playerStep = 2;
        // name = "home";
        // host = getClientHost();
        // are the icons already loaded?
        if (icons == null)
        {
            loadGraphics();
        }

        // set a default constraint
        setConstraint(0, 0, 5, 5);
    }

    /**
     * Class constructor
     * 
     * @param x
     *            Starting horizontal position
     * @param y
     *            Starting hotizontal position
     * @param c
     *            Colour of player
     * @param n
     *            Name of player
     * @param h
     *            Hostname of client
     * @throws ServerNotActiveException
     */
    public Player(int x, int y, Color c, String n) throws RemoteException,
            ServerNotActiveException
    {
        xPos = x;
        yPos = y;
        uniformColour = c;
        currentDirection = Direction.LEFT;
        playerStep = 2;
        name = n;
        host = getClientHost();
        // are the icons already loaded?
        if (icons == null)
        {
            loadGraphics();
        }

        // set a default constraint
        setConstraint(0, 0, 5, 5);
    }

    /**
     * Class constructor which includes a MediaTracker object to make sure
     * images are loaded
     * 
     * @param x
     *            Starting horizontal position
     * @param y
     *            Starting vertical position
     * @param c
     *            Colour of player
     * @param mt
     *            MediaTracker object
     * @throws ServerNotActiveException
     */
    public Player(int x, int y, Color c, MediaTracker mt)
            throws RemoteException, ServerNotActiveException
    {
        xPos = x;
        yPos = y;
        uniformColour = c;
        currentDirection = Direction.LEFT;
        playerStep = 2;
        // name = "home";
        // host = getClientHost();
        mediaTracker = mt;
        // are the icons already loaded?
        if (icons == null)
        {
            loadGraphics();
        }

        // set a default constraint
        setConstraint(0, 0, 5, 5);
    }

    /**
     * Loads the icons for the players
     */
    private void loadGraphics()
    {
        String direct[] =
            { "l", "r", "u", "d" };
        icons = new Image[numberOfDirections][numberOfFrames];
        for (int i = 0; i < numberOfDirections; i++)
        {
            String filename = "images/" + direct[i];
            for (int j = 0; j < numberOfFrames; j++)
            {
                icons[i][j] = Toolkit.getDefaultToolkit().getImage(
                        filename + (j + 1) + ".png");
                if (mediaTracker != null)
                {
                    mediaTracker.addImage(icons[i][j], 0);
                }
            }
        }
    }

    /**
     * Contrain the movement of the player to a certain bounding box
     * 
     * @param x1
     *            Minimum horizontal limit
     * @param y1
     *            Minimum vertical limit
     * @param x2
     *            Maximum horizontal limit
     * @param y2
     *            Maximum vertical limit
     */
    public void setConstraint(int x1, int y1, int x2, int y2)
    {
        xMin = x1;
        yMin = y1;
        xMax = x2;
        yMax = y2;
    }

    /**
     * Move the player 1 step in a particular direction
     * 
     * @param d
     *            Direction of movement
     * @throws ServerNotActiveException
     */
    public synchronized void move(Direction d)
    {

        // update the icon to use
        playerStep++;

        if (playerStep >= numberOfFrames)
        {
            playerStep = 0;
        }

        currentDirection = d;

        switch (d)
        {
        case LEFT:
            if (xPos > xMin) xPos--;
            break;
        case RIGHT:
            if (xPos < xMax) xPos++;
            break;
        case UP:
            if (yPos > yMin) yPos--;
            break;
        case DOWN:
            if (yPos < yMax) yPos++;
            break;
        }

    }

    /**
     * Check to see if a player is at a specific location
     * 
     * @param x
     *            horizontal location
     * @param y
     *            vertical location
     * @return True if player is at specified location
     */
    public boolean atLocation(int x, int y)
    {
        return ((x == xPos) && (y == yPos));
    }

    /**
     * Get the current image for the player
     * 
     * @return Image of current player
     */
    public Image getPersonGraphic()
    {
        return (icons[currentDirection.ordinal()][playerStep]);
    }

    /**
     * Get the horizontal location of player
     * 
     * @return horizontal location of player
     */

    public int getXPos()
    {
        return xPos;
    }

    /**
     * Get the vertical location of player
     * 
     * @return vertical location of player
     */
    public int getYPos()
    {
        return yPos;
    }

    /**
     * Get the player colour
     * 
     * @return Player colour
     */
    public Color getColour()
    {
        return uniformColour;
    }

    public String getName()
    {
        return name;
    }

    public String getHost()
    {
        return host;
    }

}
