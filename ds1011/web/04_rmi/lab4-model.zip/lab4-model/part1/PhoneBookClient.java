package part1;

import java.net.MalformedURLException;
import java.rmi.Naming;
import java.rmi.NotBoundException;
import java.rmi.RemoteException;
import java.util.Map.Entry;

import part1.Contact.PhoneType;

public class PhoneBookClient
{
    /**
     * Print a few lines to the console describing the given contact.
     * 
     * @param contact
     */
    private static void displayContact(Contact contact)
    {
        System.out.println("Name: " + contact.getName());
        for(Entry<String, PhoneType> phoneNumberEntry : contact.getPhoneNumbers().entrySet())
        {
            System.out.println(" " + phoneNumberEntry.getKey() 
                    + " (" + phoneNumberEntry.getValue() + ")");
        }
    }

    /**
     * Print a list of all names of contacts present in the given phone book.
     * 
     * @param phoneBook to print names from
     * @throws RemoteException 
     */
    private static void displayPhoneBookNames(PhoneBookInterface phoneBook) throws RemoteException
    {
        for (String name : phoneBook.getNames())
        {
            System.out.println(name);
        }
    }

    /**
     * Main program
     * @throws RemoteException 
     * @throws NotBoundException 
     * @throws MalformedURLException 
     */
    public static void main(String[] args) throws RemoteException, MalformedURLException, NotBoundException
    {
        PhoneBookInterface myFriends = 
            (PhoneBookInterface) Naming.lookup("rmi://localhost:1099/MyFriends" );
        
        if(myFriends.getContact("Donald Duck") != null)
        {
            System.out.println("phone book is already set up!");
            
            displayPhoneBookNames(myFriends);
        }
        else
        {
            System.out.println("adding contacts...");

            Contact donuldDuck = new Contact("Donald Duck");
            donuldDuck.addPhoneNumber("121212", PhoneType.HOMETEL);
            myFriends.add(donuldDuck);
            
            Contact frodo = new Contact("Frodo");
            frodo.addPhoneNumber("10011001", PhoneType.WORKMOBILE);
            frodo.addPhoneNumber("10101010", PhoneType.HOMETEL);
            myFriends.add(frodo);
            
            Contact arthur = new Contact("Arthur");
            arthur.addPhoneNumber("1", PhoneType.WORKTEL);
            myFriends.add(arthur);
        }
        
        System.out.println();
        
        for(String name : myFriends.getNames())
        {
            displayContact(myFriends.getContact(name));
            System.out.println();
        }
        
    }

}
