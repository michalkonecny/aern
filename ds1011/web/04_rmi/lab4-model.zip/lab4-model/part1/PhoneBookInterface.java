package part1;

import java.rmi.Remote;
import java.rmi.RemoteException;

public interface PhoneBookInterface extends Remote
{
    /**
     * The default rmi registry name of a PhoneBook instance.
     */
    static final String DEFAULT_SERVER_NAME = "PhoneBookServer";
    
    /**
     * @param name -
     *            The name of the contact to be looked up in the phone book
     * @return a Contact object for the given name
     */
    Contact getContact(String name) throws RemoteException;

    /**
     * @param name -
     *            The name of the contact to be deleted from phone book
     */
    void delete(String name) throws RemoteException;

    /**
     * @return a String array of all the contact names in the phone book
     */
    String[] getNames() throws RemoteException;

    /**
     * @param contact -
     *            An contact record to add to the phone book.
     */
    void add(Contact contact) throws RemoteException;
}
