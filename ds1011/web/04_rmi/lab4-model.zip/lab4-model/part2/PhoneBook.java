package part2;

import java.rmi.Naming;
import java.rmi.RMISecurityManager;
import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.server.UnicastRemoteObject;
import java.util.HashMap;
import java.util.Map;

public class PhoneBook extends UnicastRemoteObject implements PhoneBookInterface
{
    private static final long serialVersionUID = 8449908502307339621L;

    protected PhoneBook() throws RemoteException
    {
        super();
    }

    private Map<String, Contact> contacts = new HashMap<String, Contact>();

    /**
     * @param contact -
     *            An contact record to add to the phone book.
     * @throws RemoteException 
     */
    public void add(String name) throws RemoteException
    {
        contacts.put(name, new Contact(name));
    }

    /**
     * @param name -
     *            The name of the contact to be looked up in the phone book
     * @return a Contact object for the given name
     */
    public ContactInterface getContact(String name)
    {
        return contacts.get(name);
    }

    /**
     * @param name -
     *            The name of the contact to be deleted from phone book
     */
    public void delete(String name)
    {
        contacts.remove(name);
    }

    /**
     * @return a String array of all the contact names in the phone book
     */
    public String[] getNames()
    {
        return contacts.keySet().toArray(new String[0]);
    }

    
    public static void main(String[] args)
    {
        System.out.printf("setting security manager...");
        System.setSecurityManager(new RMISecurityManager());
        System.out.printf("ok\n");

        try
        {
            // create application:
            System.out.printf("creating application...");
            PhoneBook serverObject = new PhoneBook();
            System.out.printf("ok\n");

            // create rmi registry:
            System.out.printf("creating rmi registry...");
            LocateRegistry.createRegistry(1099);
            System.out.printf("ok\n");

            // bind server name to this application:
            System.out.printf("rebinding...");
            Naming.rebind("MyFriends", serverObject);
            System.out.printf("ok\n");
        }
        catch (Exception e)
        {
            System.out.println("An exception occured while creating server");
            e.printStackTrace();
        }
    }

}
