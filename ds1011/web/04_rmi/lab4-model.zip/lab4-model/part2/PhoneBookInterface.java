package part2;

import java.rmi.Remote;
import java.rmi.RemoteException;

public interface PhoneBookInterface extends Remote
{
    /**
     * The default rmi registry name of a PhoneBook instance.
     */
    static final String DEFAULT_SERVER_NAME = "PhoneBookServer";
    
    /**
     * @param name -
     *            The name of the contact to be looked up in the phone book
     * @return a Contact remote object for the given name
     */
    ContactInterface getContact(String name) throws RemoteException;

    /**
     * @param name -
     *            The name of the contact to be deleted from phone book
     */
    void delete(String name) throws RemoteException;

    /**
     * @return a String array of all the contact names in the phone book
     */
    String[] getNames() throws RemoteException;

    /**
     * @param name -
     *            The name of a new contact to add to the phone book.
     */
    void add(String name) throws RemoteException;
}
