package part2;

import java.rmi.Remote;
import java.rmi.RemoteException;
import java.util.Map;

public interface ContactInterface extends Remote
{

    public static enum PhoneType
    {
        MOBILE, HOMETEL, WORKTEL, WORKFAX, WORKMOBILE
    }

    /**
     * @return the contact's name
     */
    String getName() throws RemoteException;

    /**
     * @return the contact's phone numbers
     */
    Map<String, PhoneType> getPhoneNumbers()  throws RemoteException;

    /**
     * Add a new phone number to this contact.
     * 
     * @param number a phone number
     * @param type a phone number type
     */
    void addPhoneNumber(String number, PhoneType type)  throws RemoteException;

}