package part2;

import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;
import java.util.HashMap;
import java.util.Map;

public class Contact extends UnicastRemoteObject implements ContactInterface
{
    private static final long serialVersionUID = 3882166821263947054L;
    
    private String name;
    private Map<String, PhoneType> phoneNumbers;

    /**
     * A standard constructor, initialising fields directly from its
     * parameters.
     * <br/>
     * By default the contact has no phone numbers.
     * Use method {@link #addPhoneNumber(String, PhoneType)} to specify
     * contact's phone numbers.
     * 
     * @param name contact's name
     * @throws RemoteException 
     */
    public Contact(String name) throws RemoteException
    {
        super();
        this.name = name;
        this.phoneNumbers = new HashMap<String, PhoneType>();
    }

    /* (non-Javadoc)
     * @see part2.ContactInterface#getName()
     */
    public String getName()
    {
        return name;
    }

    /* (non-Javadoc)
     * @see part2.ContactInterface#getPhoneNumbers()
     */
    public Map<String, PhoneType> getPhoneNumbers()
    {
        return phoneNumbers;
    }

    /* (non-Javadoc)
     * @see part2.ContactInterface#addPhoneNumber(java.lang.String, part2.Contact.PhoneType)
     */
    public void addPhoneNumber(String number, PhoneType type)
    {
        phoneNumbers.put(number, type);
    }
}
