package tests;

import java.net.MalformedURLException;
import java.rmi.Naming;
import java.rmi.NotBoundException;
import java.rmi.RemoteException;
import java.rmi.server.ServerNotActiveException;
import java.rmi.server.UnicastRemoteObject;
import java.util.Random;

import objects.Direction;
import objects.PlayerInterface;
import objects.PositionListenerInterface;
import server.BoardServerConstants;
import server.BoardServerInterface;

public class MoveManyMen
{
    private static final int numberOfMen = 50;

    private static class ManListener 
        extends UnicastRemoteObject 
        implements PositionListenerInterface
    {
        private static final long serialVersionUID = 3681737296155391340L;
        
        private String name;

        protected ManListener(String name) throws RemoteException
        {
            super();
            this.name = name; 
        }

        @Override
        public String newPosition(int x, int y) throws RemoteException
        {
            System.out.printf
            (
               "%s: our player notified us of new position: (%d,%d)\n", 
               name, x, y
            );
            return name + ": position ok";
        }
    }
    
    private static class ManThread extends Thread
    {
        private String name;
        private PlayerInterface player;
        private BoardServerInterface server;
        private Random generator;
        
        public ManThread(String name)
            throws RemoteException, ServerNotActiveException, 
                   MalformedURLException, NotBoundException
        {
            server = 
                (BoardServerInterface)
                Naming.lookup("rmi://" + BoardServerConstants.serverHost + 
                        "/" + BoardServerConstants.serverName);
            player = server.getPlayer(name);
            generator = new Random();
            this.name = name + "/" + generator.nextInt(1000);
            
            player.subscribe(new ManListener(this.name));
        }
        
        @Override
        public void run()
        {
            while ( true )
            {
                int steps = 1 + generator.nextInt(5);
                Direction d = Direction.values()[generator.nextInt(4)];
                try
                {
                    for ( int step = 0 ; step < steps; step ++)
                    {
                        String response = player.move(d);
                        System.out.printf("%s: %s", name, response);
                        Thread.sleep(200);
                    }
                    
                    // terminate this player with some small probability:
                    if (generator.nextInt(100) == 0)
                    {
                        server.hidePlayer(player);
                        break;
                    }
                }
                catch (Exception e)
                {
                    e.printStackTrace();
                }
            }
        }
    }
    
    private static void startMenThreads()
    {
        // start a thread per man:
        for (int i = 0; i < numberOfMen; i++ )
        {
            try
            {
                new ManThread("DS" + i).start();
            }
            catch (Exception e)
            {
                e.printStackTrace();
            }
        }
    }

    public static void main(String[] args) throws InterruptedException
    {
        startMenThreads();
//        Thread.sleep(10000);
//        startMenThreads;
    }
    
}
