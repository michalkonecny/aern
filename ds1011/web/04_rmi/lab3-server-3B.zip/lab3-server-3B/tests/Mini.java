package tests;

import java.net.MalformedURLException;
import java.rmi.Naming;
import java.rmi.NotBoundException;
import java.rmi.RemoteException;

import objects.Direction;
import objects.IllegalMove;
import objects.PlayerInterface;

import server.BoardServerConstants;
import server.BoardServerInterface;

public class Mini
{
    public static void main(String[] args) throws MalformedURLException,
            RemoteException, NotBoundException, InterruptedException
    {
        BoardServerInterface server = (BoardServerInterface) Naming
                .lookup("rmi://" + BoardServerConstants.serverHost + "/"
                        + BoardServerConstants.serverName);

        PlayerInterface p1 = server.getPlayer("A");
        
        Direction direction = Direction.RIGHT;
        while (true)
        {
            Thread.sleep(100);
            try
            {
                p1.move(direction);
            }
            catch(IllegalMove e)
            {
                switch(direction)
                {
                case RIGHT: direction = Direction.LEFT; break; 
                case LEFT: direction = Direction.RIGHT; break; 
                }
            }
        }
    }

}
