package objects;

import java.rmi.Remote;
import java.rmi.RemoteException;

public interface PlayerFactoryInterface extends Remote
{
    /**
     * Find an existing Player remote object
     * or create a new one and return a remote reference to it.  
     * 
     * If new, the player will be placed 
     * to a location distinct from all other active players. 
     * 
     * @param name
     * @return reference to the newly created remote Player object
     * @throws RemoteException
     */
    PlayerInterface getPlayer(String name) throws RemoteException;
    
    /**
     * Choose a new location for the player distinct from all other active players.
     * @param name
     * @throws RemoteException
     */
    void relocatePlayer(String name) throws RemoteException;
    
    /**
     * Bounds to use for players' movement and placement.
     * 
     * @param xMin
     * @param yMin
     * @param xMax
     * @param yMax
     */
    void newBounds(int xMin, int yMin, int xMax, int yMax) throws RemoteException;
    
    /**
     * Permissible colour numbers will be 0..(colLimit - 1).
     * 
     * @param colLimit
     */
    void newColourLimit(int colLimit) throws RemoteException;
}
