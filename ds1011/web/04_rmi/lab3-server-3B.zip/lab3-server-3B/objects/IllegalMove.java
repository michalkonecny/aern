package objects;

public class IllegalMove extends Exception
{
    private static final long serialVersionUID = -8289460588374832109L;

    public IllegalMove()
    {
        super("illegal move");
    }
}
