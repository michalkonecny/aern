package objects;

import java.awt.Color;
import java.awt.Graphics;

public class Circle extends Shape
{
    private static final long serialVersionUID = -8612306143551823794L;
    
    private int radius;
    private boolean filled;

    public Circle(int x, int y, int r, Color c, boolean f)
    {
        super(x, y, c);
        radius = r;
        filled = f;
    }

    public void draw(Graphics g)
    {
        super.draw(g);
        if (filled)
        {
            g.fillOval(getXpos(), getYpos(), radius, radius);
        }
        else
        {
            g.drawOval(getXpos(), getYpos(), radius, radius);
        }
    }
}
