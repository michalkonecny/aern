package objects;

/**
 * Enumerated type for specifying a direction
 */
public enum Direction
{
    LEFT, RIGHT, UP, DOWN
}
