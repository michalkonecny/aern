package objects;

import java.rmi.Remote;
import java.rmi.RemoteException;

/**
 * A remote interface of an object that listens for notification
 * of changes in a 2D position.
 */
public interface PositionListenerInterface extends Remote
{
    /**
     * A method by which a movement listener is notified
     * about a new position.
     * @return a report on the consequences of the new position
     * @param x new horizontal coordinate
     * @param y new vertical coordinate
     * @throws RemoteException
     */
    public String newPosition(int x, int y) throws RemoteException; 
}
