package objects;

import java.net.MalformedURLException;
import java.rmi.Naming;
import java.rmi.RMISecurityManager;
import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.server.UnicastRemoteObject;
import java.util.HashMap;
import java.util.Map;
import java.util.Random;

public class PlayerFactory 
    extends UnicastRemoteObject 
    implements PlayerFactoryInterface
{

    private static final long serialVersionUID = -8403831721783321585L;
    
    private Map<String,Player> players;
    private int xMin, yMin, xMax, yMax;
    private int numOfColours;
    
    private Random generator;

    public PlayerFactory() 
        throws RemoteException
    {
        super();
        generator = new Random();
        players = new HashMap<String, Player>();
    }

    public void newBounds(int xMin, int yMin, int xMax, int yMax)
    {
        this.xMin = xMin;
        this.yMin = yMin;
        this.xMax = xMax;
        this.yMax = yMax;
    }

    public void newColourLimit(int colLimit)
    {
        this.numOfColours = colLimit;
    }

    public synchronized PlayerInterface getPlayer(String name) 
        throws RemoteException
    {
        Player p = players.get(name);
        
        // if it has not been found, create it:
        if (p == null)
        {
            p = createPlayer(name);
            players.put(name, p);
            System.out.printf("getPlayer(%s): created it\n", name);
            relocatePlayer(name);
        }
        else
        {
            System.out.printf("getPlayer(%s): found it\n", name);
        }
        
        return p;
    }

    public void relocatePlayer(String name) 
        throws RemoteException
    {
        Player p = players.get(name);
        
        if (p != null)
        {
            int x, y;

            // find a vacant space on the board:
            do
            {
                x = xMin + generator.nextInt(xMax - xMin + 1);
                y = yMin + generator.nextInt(yMax - yMin + 1);
            }
            while (squareOccupied(x, y));

            p.setX(x);
            p.setY(y);
            System.out.printf("relocatePlayer(%s): new loc (%d,%d)\n", name, x, y);
        }
    }

    public void playerNoLongerActive(String name) throws RemoteException
    {
        players.remove(name);
        System.out.printf("playerNoLongerActive(%s): ok\n", name);
    }
    
    // check to see if a square on the grid is already occupied
    private boolean squareOccupied(int x, int y) 
        throws RemoteException
    {
        // cycle through players checking their location
        for (Player p : players.values())
        {
            if (p.atLocation(x, y)) { return true; }            
        }
        
        return false;
    }
    
    private Player createPlayer(String name)
        throws RemoteException
    {

        Player newPlayer = 
            new Player
                (
                        xMin, yMin,
                        generator.nextInt(1000) % numOfColours, 
                        name, 
                        xMin, yMin, xMax, yMax,
                        this
                );
        
        return newPlayer;
    }
    
    public static void main(String[] args) 
        throws RemoteException, MalformedURLException
    {
        System.setSecurityManager(new RMISecurityManager());
        
        PlayerFactory factory = new PlayerFactory();
        
        try { LocateRegistry.createRegistry(1099); } catch(Exception e) {;}
        
        Naming.rebind("PlayerFactory", factory);
    }
}
