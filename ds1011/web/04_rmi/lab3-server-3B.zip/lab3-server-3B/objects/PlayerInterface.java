package objects;

import java.rmi.Remote;
import java.rmi.RemoteException;


public interface PlayerInterface extends Remote
{
    public static final int numberOfFrames = 4;

    /**
     * @return current horizontal coordinate of player
     * @throws RemoteException
     */
    public int getXPos() throws RemoteException;
    
    /**
     * @return current vertical coordinate of player
     * @throws RemoteException
     */
    public int getYPos() throws RemoteException;
    
    /**
     * Add a new position listener to the player.
     * @param listener
     * @throws RemoteException
     */
    public void subscribe(PositionListenerInterface listener) throws RemoteException;
    
    /**
     * Change the position of the player.
     * (And notify all listeners of this change.)
     * @return a report on the outcome of the move
     * @param d
     * @throws RemoteException
     * @throws IllegalMove 
     */
    String move(Direction d) throws RemoteException, IllegalMove;

    /**
     * Test whether the player as at this particular position
     * @param x
     * @param y
     * @return true - iff the player is at (x,y)
     * @throws RemoteException
     */
    boolean atLocation(int x, int y) throws RemoteException;

    /**
     * @return current phase of the player's movement (current step number modulo number of frames)
     * @throws RemoteException
     */
    public int getStep() throws RemoteException;

    /**
     * @return the direction of the last step made
     * @throws RemoteException
     */
    public Direction getDirection() throws RemoteException;

    /**
     * @return the colour the player is setup to use
     * @throws RemoteException
     */
    public int getColour() throws RemoteException;

    /**
     * @return player's name
     * @throws RemoteException
     */
    public String getName() throws RemoteException;

    /**
     * @return player's creating host
     * @throws RemoteException
     */
    public Object getHost() throws RemoteException;
}
