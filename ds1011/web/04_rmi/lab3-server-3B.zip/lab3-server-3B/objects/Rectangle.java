package objects;

import java.awt.Color;
import java.awt.Graphics;

/**
 * Rectangle class extends Shape class
 * 
 * @author ingrambr
 * 
 */
public class Rectangle extends Shape
{

    private static final long serialVersionUID = -3811604475186691868L;
    
    private int width;
    private int height;
    private boolean filled;

    /**
     * Class Constructor
     * 
     * @param x
     *            the horizontal position of the rectangle
     * @param y
     *            the vertical position of the rectangle
     * @param w
     *            the width of the rectangle
     * @param h
     *            the height of the rectangle
     * @param c
     *            the colour of the rectangle
     * @param f
     *            is it filled?
     */
    public Rectangle(int x, int y, int w, int h, Color c, boolean f)
    {
        super(x, y, c);
        width = w;
        height = h;
        filled = f;
    }

    /**
     * Draws the rectangle on the supplied graphics object
     * 
     * @param Graphics
     *            object of where to draw rectangle
     * 
     */
    public void draw(Graphics g)
    {
        super.draw(g);
        if (filled)
        {
            g.fillRect(getXpos(), getYpos(), width, height);
        }
        else
        {
            g.drawRect(getXpos(), getYpos(), width, height);
        }
    }
}
