package objects;

import java.rmi.RemoteException;
import java.rmi.server.ServerNotActiveException;
import java.rmi.server.UnicastRemoteObject;
import java.rmi.server.Unreferenced;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

/**
 * Player class for representing a player in a game
 * 
 * @author ingrambr, konecnym
 * 
 */
public class Player 
    extends UnicastRemoteObject 
    implements PlayerInterface, Unreferenced
{
    private static final long serialVersionUID = -5684813679858405222L;

    private int xPos, yPos; // position of player on board
    private int xMin, yMin, xMax, yMax; // area where player movement is
                                        // constrained
    private String name;
    private String host;
    private int uniformColour;
    
    private Direction currentDirection; // direction that the player is facing
    private int currentStep; // icon in sequence to use

    
    private Set<PositionListenerInterface> listeners;

    private PlayerFactory factory;


    /**
     * Class constructor
     * 
     * @param x
     *            Starting horizontal position
     * @param y
     *            Starting vertical position
     * @param c
     *            Colour of player
     * @param name
     *            Name of player
     * @param xMin
     *            Minimum horizontal limit
     * @param yMin
     *            Minimum vertical limit
     * @param xMax
     *            Maximum horizontal limit
     * @param yMax
     *            Maximum vertical limit
     * @param factory
     *            the factory managing this instance
     * @throws ServerNotActiveException
     */
    public Player
        (
                int x, int y, int col, 
                String name, 
                int xMin, int yMin, int xMax, int yMax,
                PlayerFactory factory
        ) 
        throws RemoteException
    {
        xPos = x;
        yPos = y;
        uniformColour = col;
        currentDirection = Direction.LEFT;
        currentStep = 2;
        this.name = name;
        this.factory = factory;
        
        try
        {
            host = getClientHost();
        }
        catch (ServerNotActiveException e)
        {
            host = "localhost";
        }

        this.xMin = xMin;
        this.yMin = yMin;
        this.xMax = xMax;
        this.yMax = yMax;
        
        listeners = new HashSet<PositionListenerInterface>();
    }


    /**
     * Move the player 1 step in a particular direction
     * 
     * @param d
     *            Direction of movement
     * @throws IllegalMove 
     * @throws ServerNotActiveException
     */
    public synchronized String move(Direction d) throws IllegalMove
    {
        currentStep = (currentStep + 1) % numberOfFrames;
        currentDirection = d;

        switch (d)
        {
        case LEFT:
            if (xPos > xMin) { xPos--; } else { throw new IllegalMove(); };
            break;
        case RIGHT:
            if (xPos < xMax) { xPos++; } else { throw new IllegalMove(); };
            break;
        case UP:
            if (yPos > yMin) { yPos--; }  else { throw new IllegalMove(); };
            break;
        case DOWN:
            if (yPos < yMax) { yPos++; }  else { throw new IllegalMove(); };
            break;
        }
        
        return notifyListeners();
    }

    private String notifyListeners()
    {
        String report = "";
        // for each listener...
        Iterator<PositionListenerInterface> it = listeners.iterator();
        while (it.hasNext())
        {
            PositionListenerInterface listener = it.next();
            try
            {
                // attempt to notify the listener of our new position:
                String listenerReport = listener.newPosition(xPos, yPos); 
                report +=  listenerReport + "\n";
            }
            catch(RemoteException e)
            {
                // if there was a failure, assume the listener died:
                it.remove();
            }
        }
        
        return report;
    }

    /**
     * Check to see if a player is at a specific location
     * 
     * @param x
     *            horizontal location
     * @param y
     *            vertical location
     * @return True if player is at specified location
     */
    public boolean atLocation(int x, int y)
    {
        return ((x == xPos) && (y == yPos));
    }

    /**
     * @return horizontal location of player
     */

    public int getXPos()
    {
        return xPos;
    }

    public void setX(int x)
    {
        this.xPos = x;
    }

    /**
     * @return vertical location of player
     */
    public int getYPos()
    {
        return yPos;
    }

    public void setY(int y)
    {
        this.yPos = y;
    }

    public int getColour() throws RemoteException
    {
        return uniformColour;
    }

    
    public String getName() throws RemoteException
    {
        return name;
    }

    public String getHost() throws RemoteException
    {
        return host;
    }

    public void subscribe(PositionListenerInterface listener)
            throws RemoteException
    {
        listeners.add(listener);
    }


    public Direction getDirection() throws RemoteException
    {
        return currentDirection;
    }

    public int getStep() throws RemoteException
    {
        return currentStep;
    }

    public void unreferenced()
    {
        try
        {
            factory.playerNoLongerActive(name);
        }
        catch (RemoteException e)
        {
            e.printStackTrace();
        }
    }


}
