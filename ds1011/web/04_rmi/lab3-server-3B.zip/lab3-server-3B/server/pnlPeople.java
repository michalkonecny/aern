package server;

import java.awt.Graphics;
import java.awt.Image;
import java.awt.MediaTracker;
import java.awt.Toolkit;
import java.awt.Color;
import java.awt.image.BufferedImage;

import javax.swing.JPanel;

import java.net.MalformedURLException;
import java.rmi.Naming;
import java.rmi.NotBoundException;
import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;

import java.util.HashMap;
import java.util.Map;

import objects.PlayerFactoryInterface;
import objects.PlayerInterface;
import objects.PositionListenerInterface;
import objects.Direction;

public class pnlPeople extends JPanel
{

    private static final long serialVersionUID = -6991217044763959938L;

    private final int xGridSize = 30;
    private final int yGridSize = 15;
    private final int squareSize = 20;

    private final Color backgroundColour = new Color(32, 96, 32);
    private final Color[] colourList =
        { Color.blue, Color.cyan, Color.orange, Color.red, Color.pink,
                Color.yellow, Color.pink, Color.gray, Color.magenta };

    private BufferedImage img;
    private Graphics gArea;
    private MediaTracker mediaTracker;
    private Image imgDuck;
    private static Image[][] icons;    

    private static final String playerFactoryURI = "rmi://localhost/PlayerFactory";
    private PlayerFactoryInterface playerFactory;
    
    private Map<String,PlayerInterface> players;
    private PlayerInterface duck;
    private int position;

    public pnlPeople() throws RemoteException, MalformedURLException, NotBoundException
    {
        super();
        initialize();
    }

    private synchronized void initialize() 
        throws RemoteException, MalformedURLException, NotBoundException
    {
        mediaTracker = new MediaTracker(this);

        // create an image that is the same size as field of play
        img = new BufferedImage(xGridSize * squareSize, yGridSize * squareSize,
                BufferedImage.TYPE_INT_RGB);
        gArea = img.getGraphics();
        
        // create structures to keep track of players:
        players = new HashMap<String,PlayerInterface>();
        loadPlayerIcons();
        
        playerFactory =
//            new PlayerFactory();
            (PlayerFactoryInterface) Naming.lookup(playerFactoryURI);
        playerFactory.newBounds(0, 0, xGridSize - 1, yGridSize - 1);
        playerFactory.newColourLimit(colourList.length);
        
        // Load duck icon:
        imgDuck = Toolkit.getDefaultToolkit().getImage("images/duck.png");
        mediaTracker.addImage(imgDuck, 0);
        // create the "duck" player:
        duck = playerFactory.getPlayer("duck");
        placeDuck();

        // initialise the position of the next person who finds the duck
        position = 1;

        try
        {
            mediaTracker.waitForID(0);
        }
        catch (InterruptedException e)
        {
            e.printStackTrace();
        }

        updateImage();
    }

    /**
     * Loads the icons for the players
     */
    private void loadPlayerIcons()
    {
        String direct[] =
            { "l", "r", "u", "d" };
        icons = new Image[Direction.values().length][PlayerInterface.numberOfFrames];
        for (int i = 0; i < Direction.values().length; i++)
        {
            String filename = "images/" + direct[i];
            for (int j = 0; j < PlayerInterface.numberOfFrames; j++)
            {
                icons[i][j] = Toolkit.getDefaultToolkit().getImage(
                        filename + (j + 1) + ".png");
                if (mediaTracker != null)
                {
                    mediaTracker.addImage(icons[i][j], 0);
                }
            }
        }
    }    
    
    private void subscribeToPlayer(final PlayerInterface player) 
        throws RemoteException
    {
        player.subscribe(new PlayerListener(player));
//        player.subscribe
//            (
//                    new PositionListenerInterface()
//                    {
//                        public String newPosition(int x, int y) 
//                            throws RemoteException
//                        {   
//                            return playerMoved(player);
//                        }
//                    }
//            );
    }

    private class PlayerListener 
        extends UnicastRemoteObject 
        implements PositionListenerInterface
    {
        private static final long serialVersionUID = 7552567727669253086L;
        
        private PlayerInterface player;

        protected PlayerListener(PlayerInterface player) 
            throws RemoteException
        {
            super();
            this.player = player;
        }

        public String newPosition(int x, int y) 
            throws RemoteException
        {
            return playerMoved(player);
        }
    }
    
    
    private void placeDuck() throws RemoteException
    {
        playerFactory.relocatePlayer(duck.getName());
    }

    private synchronized void updateImage() 
        throws RemoteException
    {
        // set background colour of Image
        gArea.setColor(backgroundColour);
        gArea.fillRect(0, 0, 
                       xGridSize * squareSize, 
                       yGridSize * squareSize);

        // draw the duck
        gArea.drawImage
            (
                    imgDuck, 
                    duck.getXPos() * squareSize, 
                    duck.getYPos() * squareSize, 
                    null
            );

        // cycle through players and add them to Image
        for(PlayerInterface p : players.values())
        {
            drawPlayer(p);
        }
        
        repaint();
    }

    private void drawPlayer(PlayerInterface p) 
        throws RemoteException
    {
        int xPlot = p.getXPos() * squareSize;
        int yPlot = p.getYPos() * squareSize;
        gArea.drawImage
            (
                    icons[p.getDirection().ordinal()][p.getStep()], 
                    xPlot, yPlot, null
            );

        // if the Player is on the top line of grid, display number below
        if (yPlot == 0)
        {
            yPlot = yPlot + 30;
        }

        // print the Player number
        gArea.setColor(colourList[p.getColour()]);
        gArea.drawString(p.getName(), xPlot, yPlot);
    }

    public void paintComponent(Graphics g)
    {
        g.drawImage(img, 0, 0, null);
    }


    private String playerMoved(PlayerInterface player)
        throws RemoteException
    {
        String result;

        synchronized (this)
        {
            if (player.atLocation(duck.getXPos(), duck.getYPos()))
            {
                placeDuck();
                result = "Got the duck. Congratulations! You are placed: " + position;
                position++;
            }
            else
            {
                result = "Unlucky! Try again!";
            }
        }

        updateImage();

        return result;
    }

    public synchronized PlayerInterface getPlayer(String name) 
        throws RemoteException
    {
        PlayerInterface p = playerFactory.getPlayer(name);
        
        if ( players.get(name) == null ) // new player?
        {
            // new player must be registered for drawing:
            players.put(name, p);
            updateImage();
            // ensure the big brother will be notified about all
            // movements of this player:
            subscribeToPlayer(p);
        }
        
        return p;
    }

    public synchronized void hidePlayer(PlayerInterface p) 
        throws RemoteException
    {
        players.remove(p.getName());
        updateImage();
    }
}
