package server;

import java.awt.AlphaComposite;
import java.awt.Color;
import java.awt.Composite;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import javax.swing.JPanel;

import objects.Line;

public class pnlScribble extends JPanel
{

    private int xSize;
    private int ySize;
    private BufferedImage img;
    private Graphics2D gArea;

    /**
     * This is the default constructor
     */
    public pnlScribble(int x, int y)
    {
        super();
        xSize = x;
        ySize = y;
        initialize();
    }

    /**
     * This method initializes this
     * 
     * @return void
     */
    private void initialize()
    {
        this.setSize(xSize, ySize);
        img = new BufferedImage(xSize, ySize, BufferedImage.TYPE_INT_ARGB);
        gArea = (Graphics2D) img.getGraphics();
        gArea.setColor(Color.BLACK);
        gArea.fillRect(0, 0, xSize, ySize);
    }

    public void addLine(Line l)
    {

        // fade the image by drawing a semi-transparent rectangle on top
        Composite originalComposite = gArea.getComposite();
        gArea.setComposite(AlphaComposite.getInstance(AlphaComposite.SRC_OVER,
                (float) 0.01));
        gArea.setColor(Color.BLACK);
        gArea.fillRect(0, 0, xSize, ySize);
        gArea.setComposite(originalComposite);

        // draw line
        l.draw(gArea);

        repaint();
    }

    public void paintComponent(Graphics g)
    {
        g.drawImage(img, 0, 0, null);
    }
}
