package server;

import java.awt.FlowLayout;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;

import objects.*;


import java.awt.Color;

/**
 * Creates a TextBox panel object
 * 
 * @author ingrambr
 * 
 */
public class pnlTextBox extends JPanel
{
    final private static String newline = System.getProperty("line.separator");
    private JTextArea textBox;
    private JScrollPane scrollPane;

    /**
     * Class Constructor
     */
    public pnlTextBox()
    {
        super();
        initialize();
    }

    private void initialize()
    {
        this.setSize(200, 600);
        this.setLayout(new FlowLayout());

        // create a TextArea with 37 rows and 16 columns
        textBox = new JTextArea("", 45, 20);
        textBox.setLineWrap(true);

        // make the text area scrollable
        scrollPane = new JScrollPane(textBox);
        scrollPane
                .setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);

        // set the font and colour
        textBox.setFont(new java.awt.Font("Lucida Console", 0, 10));
        textBox.setForeground(Color.blue);

        this.add(scrollPane);
        this.setVisible(true);
    }

    /**
     * Send a message to the textbox
     * 
     * @param m
     *            Message object that contains message to be displayed
     */
    public void sendMessage(Message m)
    {

        // add text to TextArea
        textBox.append(m.getHostname() + " : " + newline);
        textBox.append(m.getText() + newline + newline);

        // we want the TextArea to scroll
        textBox.setCaretPosition(textBox.getDocument().getLength());
    }

}
