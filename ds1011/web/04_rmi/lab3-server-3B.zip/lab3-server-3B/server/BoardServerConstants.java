package server;

public class BoardServerConstants
{

    public static final String serverName = "CS3250Server"; // name of the server
//    public static final String serverHost = "cs-teaching1.aston.ac.uk";
    public static final String serverHost = "localhost";

    public static final int numberOfDefaultPlayers = 4;
    
}
