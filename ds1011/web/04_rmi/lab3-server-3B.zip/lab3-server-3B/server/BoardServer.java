package server;

import java.net.MalformedURLException;
import java.rmi.Naming;
import java.rmi.NotBoundException;
import java.rmi.RMISecurityManager;
import java.rmi.RemoteException;
import java.rmi.server.ServerNotActiveException;
import java.rmi.server.UnicastRemoteObject;
import javax.swing.SwingUtilities;

import objects.*;
import sun.misc.Perf.GetPerfAction;

/**
 * Main application class. It creates a server and a GUI.
 * 
 * @author ingrambr
 * 
 */
public class BoardServer extends UnicastRemoteObject implements
        BoardServerInterface
{

    private static BoardServer serverObject;
    private static frmMain GUI;

    /**
     * @throws RemoteException
     */
    public BoardServer() throws RemoteException
    {
        super();
    }

    public String sayHello(String s) throws RemoteException
    {
        String Message = "Hello! You sent me: " + s;
        return Message;
    }

    public void drawLine(Line l) throws RemoteException
    {
        GUI.getScribbleArea().addLine(l);
    }

    public void drawShape(Shape s) throws RemoteException
    {
        GUI.getShapesArea().addShape(s);
    }

    public void sendMessage(Message m) throws RemoteException
    {
        GUI.getTextArea().sendMessage(m);
    }

    public PlayerInterface getPlayer(String name) 
        throws RemoteException, MalformedURLException, NotBoundException
    {
        return (GUI.getPeopleArea()).getPlayer(name);
    }

    public void hidePlayer(PlayerInterface p) 
        throws RemoteException, MalformedURLException, NotBoundException
    {
        (GUI.getPeopleArea()).hidePlayer(p);        
    }

    
    /**
     * @param args
     */
    public static void main(String[] args)
    {

        // create GUI
        SwingUtilities.invokeLater(new Runnable()
        {
            public void run()
            {
                try
                {
                    GUI = new frmMain();
                    GUI.setVisible(true);
                }
                catch (Exception e)
                {
                    e.printStackTrace();
                }
            }
        });

        System.out.printf("setting security manager...");
        System.setSecurityManager(new RMISecurityManager());
        System.out.printf("ok\n");

        try
        {
            // create application
            System.out.printf("creating application...");
            serverObject = new BoardServer();
            System.out.printf("ok\n");

            // bind server name to this application

            System.out.printf("rebinding...");
            Naming.rebind(BoardServerConstants.serverName, serverObject);
            System.out.printf("ok\n");
        }
        catch (Exception e)
        {
            System.out.println("An Exception occured while creating server");
            e.printStackTrace();
        }

    }

}
