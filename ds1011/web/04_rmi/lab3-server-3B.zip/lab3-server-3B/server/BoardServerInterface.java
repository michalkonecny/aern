package server;

import java.net.MalformedURLException;
import java.rmi.*;
import java.rmi.server.ServerNotActiveException;

import objects.*;


/**
 * @author ingrambr
 * 
 */
public interface BoardServerInterface extends Remote
{

    /**
     * Find an existing Player remote object or create a new one 
     * and return a remote reference to it.
     * 
     * @param name
     * @return reference to the newly created remote Player object
     * @throws RemoteException
     * @throws NotBoundException 
     * @throws MalformedURLException 
     */
    PlayerInterface getPlayer(String name) throws RemoteException, MalformedURLException, NotBoundException;

    /**
     * Ensure that this player is no longer shown.
     * @param p
     * @throws RemoteException
     * @throws NotBoundException 
     * @throws MalformedURLException 
     */
    void hidePlayer(PlayerInterface p) throws RemoteException, MalformedURLException, NotBoundException;

}
