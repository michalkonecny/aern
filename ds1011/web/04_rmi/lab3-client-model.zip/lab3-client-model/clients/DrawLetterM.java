package clients;

import java.awt.Color;
import java.rmi.*;

import objects.Circle;
import objects.Line;
import objects.Rectangle;

import server.BoardServerInterface;

public class DrawLetterM
{

    public static void main(String args[])
    {
        final String serverHost = "duck.aston.ac.uk";
        final String serverName = "CS3250Server"; // was TODO
        final String registryURI = "rmi://" + serverHost + "/" + serverName;

        System.setSecurityManager(new RMISecurityManager());

        try
        {

            BoardServerInterface server =
                (BoardServerInterface) Naming.lookup(registryURI); // was TODO
            
            // was TODO:
            server.drawLine(new Line(100, 100, 100, 200));
            server.drawLine(new Line(100, 200, 150, 200));
            server.drawLine(new Line(150, 200, 150, 100));
            server.drawLine(new Line(150, 100, 100, 100));
            server.drawLine(new Line(100, 150, 150, 150));

            server.drawShape(new Rectangle(50, 50, 200, 200, Color.red, true));
            server.drawShape(new Circle(70, 70, 30, Color.white, true));
            server.drawShape(new Circle(200, 200, 30, Color.white, true));
            server.drawShape(new Circle(70, 200, 30, Color.white, true));
            server.drawShape(new Circle(200, 70, 30, Color.white, true));
            server.drawShape(new Circle(135, 135, 30, Color.white, true));
            
        }
        catch (Exception e)
        {
            System.out.println("Error while performing RMI");
            e.printStackTrace();
        }
    }
}
