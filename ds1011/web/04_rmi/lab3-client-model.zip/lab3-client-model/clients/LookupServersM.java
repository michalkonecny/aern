package clients;

import java.rmi.*;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;

public class LookupServersM
{
    public static void main(String args[])
    {

        String[] names;

        System.setSecurityManager(new RMISecurityManager());
        
        try
        {
            Registry registry = 
                LocateRegistry.getRegistry
                (
                        "localhost",
                        Registry.REGISTRY_PORT
                );
            names = registry.list();
        }
        catch (Exception e)
        {
            System.out.println("Error while performing RMI");
            e.printStackTrace();
            return;
        }

        for (String name : names)
        {
            System.out.println(name);
        }

    }
}
