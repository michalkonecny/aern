package clients;
import java.rmi.*; 
import server.BoardServerInterface;

public class SimpleHelloM 
{
	 
	public static void main(String args[])
    {
        final String serverHost = "duck.aston.ac.uk";
        final String serverName = "CS3250Server"; // was TODO
        final String registryURI = "rmi://" + serverHost + "/" + serverName;
        String serverResponse;

        System.setSecurityManager(new RMISecurityManager());
        try
        {

            BoardServerInterface server = 
                (BoardServerInterface) Naming.lookup(registryURI); // was TODO
            serverResponse = 
                server.sayHello("Hello server"); // was TODO
            System.out.println(serverResponse);

        }
        catch (Exception e)
        {
            System.out.println("Error while performing RMI");
            e.printStackTrace();
        }
    }
}
