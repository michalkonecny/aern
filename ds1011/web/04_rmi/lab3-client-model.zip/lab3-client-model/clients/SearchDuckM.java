package clients;

import java.rmi.*;

import objects.Direction;
import objects.PlayerInterface;


import server.BoardServerInterface;

public class SearchDuckM
{

    public static void main(String args[])
    {
        final String serverHost = "localhost"; // was TODO;
        final String serverName = "CS3250Server"; // was TODO;
        
        int playerNum = 4;

        System.setSecurityManager(new RMISecurityManager());

        try
        {

            BoardServerInterface server =
                (BoardServerInterface) Naming.lookup("rmi://" + serverHost + "/" + serverName); // was TODO;
            
            // was TODO;
            PlayerInterface p = server.createPlayer("MK");

            // move 5 paces left
            for (int i = 0; i < 5; i++)
            {
                System.out.println(server.movePlayer(playerNum, Direction.LEFT));
                System.out.println(server.movePlayer(p, Direction.LEFT));
            }

            // move 3 paces up
            for (int i = 0; i < 3; i++)
            {
                System.out.println(server.movePlayer(playerNum, Direction.UP));
                System.out.println(server.movePlayer(p, Direction.UP));
            }

        }
        catch (Exception e)
        {
            System.out.println("Error while performing RMI");
            e.printStackTrace();
        }
    }
}
