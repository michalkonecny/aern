package standalone;

import java.util.HashMap;
import java.util.Map;

public class Contact
{
    private String name;
    private Map<String, PhoneType> phoneNumbers;

    public static enum PhoneType
    {
        MOBILE, HOMETEL, WORKTEL, WORKFAX, WORKMOBILE
    }

    /**
     * A standard constructor, initialising fields directly from its
     * parameters.
     * <br/>
     * By default the contact has no phone numbers.
     * Use method {@link #addPhoneNumber(String, PhoneType)} to specify
     * contact's phone numbers.
     * 
     * @param name contact's name
     */
    public Contact(String name)
    {
        this.name = name;
        this.phoneNumbers = new HashMap<String, PhoneType>();
    }

    /**
     * @return the contact's name
     */
    public String getName()
    {
        return name;
    }

    /**
     * @return the contact's phone numbers
     */
    public Map<String, PhoneType> getPhoneNumbers()
    {
        return phoneNumbers;
    }

    /**
     * Add a new phone number to this contact.
     * 
     * @param number a phone number
     * @param type a phone number type
     */
    public void addPhoneNumber(String number, PhoneType type)
    {
        phoneNumbers.put(number, type);
    }
}
