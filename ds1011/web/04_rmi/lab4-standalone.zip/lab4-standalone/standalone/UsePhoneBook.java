package standalone;

import java.util.Map.Entry;

import standalone.Contact.PhoneType;

public class UsePhoneBook
{
    /**
     * Print a few lines to the console describing the given contact.
     * 
     * @param contact
     */
    private static void displayContact(Contact contact)
    {
        System.out.println("Name: " + contact.getName());
        for(Entry<String, PhoneType> phoneNumberEntry : contact.getPhoneNumbers().entrySet())
        {
            System.out.println(" " + phoneNumberEntry.getKey() 
                    + " (" + phoneNumberEntry.getValue() + ")");
        }
    }

    /**
     * Print a list of all names of contacts present in the given phone book.
     * 
     * @param phoneBook to print names from
     */
    private static void displayPhoneBookNames(PhoneBook phoneBook)
    {
        for (String name : phoneBook.getNames())
        {
            System.out.println(name);
        }
    }

    /**
     * Main program
     */
    public static void main(String[] args)
    {
        PhoneBook myFriends = new PhoneBook();
        
        if(myFriends.getContact("Donald Duck") != null)
        {
            System.out.println("phone book is already set up!");
            
            displayPhoneBookNames(myFriends);
        }
        else
        {
            System.out.println("adding contacts...");

            Contact donuldDuck = new Contact("Donald Duck");
            donuldDuck.addPhoneNumber("121212", PhoneType.HOMETEL);
            myFriends.add(donuldDuck);
            
            Contact frodo = new Contact("Frodo");
            frodo.addPhoneNumber("10011001", PhoneType.WORKMOBILE);
            frodo.addPhoneNumber("10101010", PhoneType.HOMETEL);
            myFriends.add(frodo);
            
            Contact arthur = new Contact("Arthur");
            arthur.addPhoneNumber("1", PhoneType.WORKTEL);
            myFriends.add(arthur);
        }
        
        System.out.println();
        
        for(String name : myFriends.getNames())
        {
            displayContact(myFriends.getContact(name));
            System.out.println();
        }
        
    }

}
