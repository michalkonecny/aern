package standalone;

import java.util.HashMap;
import java.util.Map;

public class PhoneBook
{

    private Map<String, Contact> contacts = new HashMap<String, Contact>();

    /**
     * @param contact -
     *            An contact record to add to the phone book.
     */
    public void add(Contact contact)
    {
        contacts.put(contact.getName(), contact);
    }

    /**
     * @param name -
     *            The name of the contact to be looked up in the phone book
     * @return a Contact object for the given name
     */
    public Contact getContact(String name)
    {
        return contacts.get(name);
    }

    /**
     * @param name -
     *            The name of the contact to be deleted from phone book
     */
    public void delete(String name)
    {
        contacts.remove(name);
    }

    /**
     * @return a String array of all the contact names in the phone book
     */
    public String[] getNames()
    {
        return contacts.keySet().toArray(new String[0]);
    }

}
