package rest.chat.client;

import java.net.URI;

import com.sun.jersey.api.client.UniformInterfaceException;

public class TestSend
{
    private static final String serverURLBase = 
            "http://localhost:8080/lab6-server/";
    
    public static void main(String[] args) 
    {
        ChatServerProxy server = new ChatServerProxy(serverURLBase);
        
        String topic1 = "sport";
        String topic2 = "hw";

        createTopic(server, topic1);
        createTopic(server, topic2);
        
        sendMessage(server, topic1, "we won!");
        sendReply(server, topic1, "hooray!",1);
        sendReply(server, topic1, "boo!",1);

        sendMessage(server, topic2, "got smashing gaming pad!");
        
    }

    private static void sendMessage(ChatServerProxy server, String topic,
            String content) 
    {
        System.out.printf("sending a message to %s...", topic);
        try
        {
            URI msgURI = server.newMessage(topic, "TestSend", content);
            System.out.printf("success: URL=%s\n", msgURI);
        }
        catch(UniformInterfaceException e)
        {
            System.out.println("failed: " + e.getMessage());
        }
    }

    private static void sendReply(ChatServerProxy server, String topic,
            String content, int parentMsg) 
    {
        System.out.printf("sending a reply to msg %d in topic %s...", parentMsg, topic);
        try
        {
            URI msgURI = server.newReply(topic, "TestSend", content, parentMsg);
            System.out.printf("success: URL=%s\n", msgURI);
        }
        catch(UniformInterfaceException e)
        {
            System.out.println("failed: " + e.getMessage());
        }
    }

    private static void createTopic(ChatServerProxy server, String topic) 
    {
        System.out.printf("requesting to create a %s topic...", topic);
        try
        {
            URI topicURL = server.createTopic(topic);
            System.out.printf("success - confirmed topic %s\n", topicURL);
        }
        catch(UniformInterfaceException e)
        {
            System.out.println("failed: " + e.getMessage());
        }
    }
}
