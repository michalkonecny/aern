package rest.chat.client;

import java.util.List;

import rest.chat.messages.ChatMessage;

import com.sun.jersey.api.client.UniformInterfaceException;

public class TestFetch
{
    private static final String serverBaseURL = 
        "http://localhost:8080/lab6-server/";
    
    public static void main(String[] args) 
    {
        ChatServerProxy server = new ChatServerProxy(serverBaseURL);
        
        List<String> topics = server.getTopics();
        
        for(String topic : topics)
        {
            showAllMessages(server, topic);            
        }
//        showAllMessages(server, "test");            
    }

    private static void showAllMessages(ChatServerProxy server, String topic) 
    {
        final int msgCount = server.getMsgCount(topic);
        
        System.out.printf("Found %d messages in topic %s.\n", msgCount, topic);
        
        for (int msgNo = 1; msgNo <= msgCount; msgNo++ )
        {
            try
            {
                ChatMessage msg = server.getMessage(topic, msgNo);
                showMessage(msg);
            }
            catch(UniformInterfaceException e) 
            {
                System.out.printf("Failed to fetch message %d.\n", msgNo);
            }
        }
    }

    private static void showMessage(ChatMessage msg)
    {
        System.out.printf
        (
                "Msg %d from %s on topic %s:\n%s\n\n", 
                msg.getSerialNumber(), 
                msg.getSender(),
                msg.getTopic(),
                msg.getContent()
        );
    }
}
