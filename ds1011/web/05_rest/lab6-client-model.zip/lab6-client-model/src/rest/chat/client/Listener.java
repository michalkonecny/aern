package rest.chat.client;

import javax.ws.rs.POST;
import javax.ws.rs.Path;

import rest.chat.messages.ChatMessage;

@Path("messages")
public class Listener
{
    @POST
    public void notify(ChatMessage message)
    {
        System.out.printf("received notification of message:\n topic %s from %s:\n  %s\n", 
                message.getTopic(), message.getSender(), message.getContent());
    }
}
