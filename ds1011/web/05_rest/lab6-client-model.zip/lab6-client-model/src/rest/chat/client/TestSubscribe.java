package rest.chat.client;

public class TestSubscribe
{
    private static final String serverURLBase = 
        "http://localhost:8080/lab6-server-model/";

    public static void main(String[] args)
    {
        ChatServerProxy server = new ChatServerProxy(serverURLBase);
        server.subscribe("sport", "http://localhost:8080/lab6-client-model/");
    }
    
}
