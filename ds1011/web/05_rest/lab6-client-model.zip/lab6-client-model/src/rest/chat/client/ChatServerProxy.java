package rest.chat.client;

import java.net.URI;
import java.util.ArrayList;
import java.util.List;

import rest.chat.messages.ChatMessage;

import com.sun.jersey.api.client.Client;
import com.sun.jersey.api.client.ClientResponse;
import com.sun.jersey.api.client.UniformInterfaceException;
import com.sun.jersey.api.client.WebResource;

public class ChatServerProxy
{
    private String serverURLTopics;
    private Client restClient;
    private WebResource topicsResource;

    public ChatServerProxy(String serverURLBase) 
    {
        // initialise the base URL for topics:
        serverURLTopics = serverURLBase + "jaxrs/topics/";
        
        // create an object that can create resource proxies:
        restClient = new Client();
        
        // create a proxy for the server's topics collection
        topicsResource = restClient.resource(serverURLTopics);
    }
    
    public URI createTopic(String topicName)
    throws UniformInterfaceException
    {
        ClientResponse response = 
            topicsResource.post(ClientResponse.class, topicName);
        // check whether the server indicates an error:
        if(response.getStatus() < 400)
        {
            // return the reported resource URI:
            return response.getLocation();
        }
        else
        {
            // translate the HTTP error into Java exception:
            throw new UniformInterfaceException(response);
        }
    }
    
    public List<String> getTopics() 
    throws UniformInterfaceException
    {
        String responseString = topicsResource.get(String.class);
        
        // parse the string as a space separated list:
        String [] topicArray = responseString.split(" ");
        
        // convert the array into a list and also discard any empty strings:
        List<String> result  = new ArrayList<String>(topicArray.length);
        for(String topicRaw : topicArray)
        {
            String topic = topicRaw.trim();
            if ( ! topic.equals("") ) // ignore empty topics
            {
                result.add(topic);
            }
        }
        
        return result;
    }

    public URI newMessage(String topic, String sender, String content) 
    throws UniformInterfaceException
    {
        // construct the chat message object:
        ChatMessage msg = new ChatMessage();
        msg.setSender(sender);
        msg.setContent(content);
        
        // create a proxy for the topic's messages resource:
        WebResource messagesResource = getMessagesResource(topic);
        
        // post the new chat message and get a response containing message URL:
        ClientResponse response = 
            messagesResource.post(ClientResponse.class, msg);

        // check whether the server indicates an error:
        if(response.getStatus() < 400)
        {
            // return the reported resource URI:
            return response.getLocation();
        }
        else
        {
            // translate the HTTP error into Java exception:
            throw new UniformInterfaceException(response);
        }
    }

    public URI newReply(String topic, String sender, String content, int parentMsg) 
    throws UniformInterfaceException
    {
        // construct the chat message object:
        ChatMessage msg = new ChatMessage();
        msg.setSender(sender);
        msg.setContent(content);
        msg.setParentMsg(parentMsg);
        
        // create a proxy for the topic's messages resource:
        WebResource messagesResource = getMessagesResource(topic);
        
        // post the new chat message and get a response containing message URL:
        ClientResponse response = 
            messagesResource.post(ClientResponse.class, msg);

        // check whether the server indicates an error:
        if(response.getStatus() < 400)
        {
            // return the reported resource URI:
            return response.getLocation();
        }
        else
        {
            // translate the HTTP error into Java exception:
            throw new UniformInterfaceException(response);
        }
    }

    public int getMsgCount(String topic)
    throws UniformInterfaceException
    {
        // create a proxy to the topic's messages resource:
        WebResource messagesResource = getMessagesResource(topic);

        // get a response and parse the number from it:
        String responseString = messagesResource.get(String.class);
        return Integer.parseInt(responseString);
    }

    public ChatMessage getMessage(String topic, int msgNo) 
    throws UniformInterfaceException
    {
        // create a proxy to the message resource:
        WebResource messagesResource = getMessageResource(topic, msgNo);
        return messagesResource.get(ChatMessage.class);
    }

    private WebResource getMessagesResource(String topic)
    {
        String messagesURL = serverURLTopics + topic + "/messages/";
        return restClient.resource(messagesURL);
    }

    private WebResource getMessageResource(String topic, int msgNo)
    {
        String messagesURL = serverURLTopics + topic + "/messages/" + msgNo;
        return restClient.resource(messagesURL);
    }

    public void subscribe(String topic, String listenerURL)
    {
        String subscriptionsURL = serverURLTopics + topic + "/subscriptions";
        restClient.resource(subscriptionsURL).post(listenerURL);
    }
}

