package numbers.tests;

import java.net.URI;

import numbers.client.SamplesProxy;
import numbers.repr.SampleRepr;

public class Test
{

    public static void main(String[] args)
    {
        SamplesProxy samples = new SamplesProxy("http://localhost:8080/numbers-server/");
        URI sample1URL = samples.newSample();
        System.out.println("sample1URI = " + sample1URL);
        
        samples.addNumber(sample1URL, 1);
        samples.addNumber(sample1URL, 2);
        samples.addNumber(sample1URL, 3);
        
        SampleRepr sample1 = samples.getSample(sample1URL);
        System.out.println("sample 1 = " + sample1.getNumber());
        System.out.println("sample 1 sum = " + samples.getSum(sample1URL));
        System.out.println("sample 1 average = " + samples.getAverage(sample1URL));
        
        samples.addNumber(sample1URL, 4);
        sample1 = samples.getSample(sample1URL);
        System.out.println("sample 1 = " + sample1.getNumber());
        System.out.println("sample 1 sum = " + samples.getSum(sample1URL));
        System.out.println("sample 1 average = " + samples.getAverage(sample1URL));
        
//        samples.remove(sample1URL);
    }

}
