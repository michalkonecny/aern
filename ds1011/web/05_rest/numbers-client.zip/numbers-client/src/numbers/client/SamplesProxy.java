package numbers.client;

import java.net.URI;

import numbers.repr.SampleRepr;

import com.sun.jersey.api.client.Client;
import com.sun.jersey.api.client.ClientResponse;
import com.sun.jersey.api.client.WebResource;

public class SamplesProxy
{
    private String serverURLTopics;
    private Client restClient;
    private WebResource samplesResource;

    public SamplesProxy(String serverURLBase) 
    {
        // initialise the base URL for topics:
        serverURLTopics = serverURLBase + "jaxrs/samples/";
        
        // create an object that can create resource proxies:
        restClient = new Client();
        
        // create a proxy for the server's topics collection
        samplesResource = restClient.resource(serverURLTopics);
    }

    public URI newSample()
    {
         ClientResponse response = samplesResource.post(ClientResponse.class);
         return response.getLocation();
    }

    public SampleRepr getSample(URI sampleURL)
    {
        return restClient.resource(sampleURL).get(SampleRepr.class);
    }

    public void addNumber(URI sampleURL, double number)
    {
        restClient.resource(sampleURL).post("" + number);
    }

    public double getSum(URI sampleURL)
    {
        String sumS = restClient.resource(sampleURL + "/sum").get(String.class);
        return Double.parseDouble(sumS);
    }

    public double getAverage(URI sampleURL)
    {
        String averageS = restClient.resource(sampleURL + "/average").get(String.class);
        return Double.parseDouble(averageS);
    }

    public void remove(URI sampleURL)
    {
        restClient.resource(sampleURL).delete();
    }

}
