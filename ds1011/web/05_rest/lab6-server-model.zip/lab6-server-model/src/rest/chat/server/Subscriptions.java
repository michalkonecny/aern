package rest.chat.server;

import java.net.URI;
import java.util.Collection;
import java.util.HashMap;
import java.util.Map;

import javax.ws.rs.DELETE;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.UriBuilder;

public class Subscriptions
{
    private String topicName;
    private Map<Integer, NewMessageListenerProxy> listeners;
    private int nextListenerSerialNo;

    public Subscriptions(String topicName)
    {
        this.topicName = topicName;
        listeners = new HashMap<Integer,NewMessageListenerProxy>(); 
        nextListenerSerialNo = 1;
    }
    
    @POST
    public Response subscribe(String listenerURL) 
    {
        int subscriptionNo;
        
        synchronized(listeners)
        {
            subscriptionNo = nextListenerSerialNo;
            nextListenerSerialNo ++;
            // add the message to the collection:
            listeners.put(nextListenerSerialNo, new NewMessageListenerProxy(listenerURL));
        }
        
        URI subscriptionURL = UriBuilder.fromPath("/{subscriptionID}").build(subscriptionNo);
        return Response.created(subscriptionURL).build();
    }

    @Path("{subscriptionID:[1-9][0-9]*}")
    @DELETE
    public void delete(@PathParam("subscriptionID") String subscriptionIDS)
    {
        int subscriptionID = Integer.parseInt(subscriptionIDS);
        listeners.remove(subscriptionID);
    }

    public Collection<NewMessageListenerProxy> getListeners()
    {
        return listeners.values();
    }
}
