package rest.chat.server;

import java.net.URI;
import java.util.HashMap;
import java.util.Map;

import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.WebApplicationException;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.UriBuilder;
import javax.ws.rs.core.Response.Status;

import com.sun.jersey.spi.resource.Singleton;

@Path("topics")
@Singleton
public class Topics
{

    @GET
    public String getTopics()
    {
        String response = "";
        
        synchronized(topics)
        {
            for (String topicName : topics.keySet())
            {
                response += topicName + " ";
            }
        }
        response += "\n";

        return response;
    }

    @POST
    public Response addTopicRespondCreated(String topicName)
    {
        addTopic(topicName);
        URI topicURL = UriBuilder.fromPath("{topicName}").build(topicName);
        return Response.created(topicURL).build();
    }

    @Path("{topicName}") // topic sub-resource
    @PUT
    public void addTopic(@PathParam("topicName") String topicName)
    {
        synchronized (topics)
        {
            if (topics.containsKey(topicName))
            {
                // report conflict:
                Response response = Response.status(Status.CONFLICT).build();
                throw new WebApplicationException(response);
            } 
            else
            {
                topics.put(topicName, new Topic(topicName));
            }
        }
    }

    @Path("{topicName}") // topic sub-resource
    @DELETE
    public void deleteTopic(@PathParam("topicName") String topicName)
    {
        synchronized (topics)
        {
            if (!topics.containsKey(topicName))
            {
                throw new WebApplicationException(Status.NOT_FOUND);
            }
            topics.remove(topicName);
        }
    }
    
    @Path("{topicName}/messages") // sub-resource locator
    public Messages getMessages(@PathParam("topicName") String topicName)
    {
        return getTopic(topicName).getMessages();
    }

    @Path("{topicName}/subscriptions") // sub-resource locator
    public Subscriptions getSubscriptions(@PathParam("topicName") String topicName)
    {
        return getTopic(topicName).getSubscriptions();
    }

    private Topic getTopic(String topicName)
    {
        synchronized (topics)
        {
            if (!topics.containsKey(topicName))
            {
                Response response = Response.status(Status.NOT_FOUND).build();
                throw new WebApplicationException(response);
            }
            return topics.get(topicName);
        }
    }

    private static class Topic
    {
        private Messages messages;
        private Subscriptions subscriptions;

        public Topic(String topicName)
        {
            subscriptions = new Subscriptions(topicName);
            messages = new Messages(topicName, subscriptions);
        }

        public Subscriptions getSubscriptions()
        {
            return subscriptions;
        }

        public Messages getMessages()
        {
            return messages;
        }
    }

    private Map<String, Topic> topics = new HashMap<String, Topic>();
}
