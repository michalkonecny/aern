package rest.chat.server;

import java.net.URI;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.WebApplicationException;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.UriBuilder;
import javax.ws.rs.core.Response.Status;

import rest.chat.messages.ChatMessage;

public class Messages
{
    public Messages(String topicName, Subscriptions subscriptions)
    {
        this.topicName = topicName;
        this.subscriptions = subscriptions;
        messages = new ArrayList<ChatMessage>(); 
        nextMsgSerialNo = 1;
    }
    
    @POST
    @Consumes("application/xml")
    public Response newMessage(ChatMessage msg) 
    {
        int msgNo;
        
        synchronized(messages)
        {
            msgNo = nextMsgSerialNo;
            nextMsgSerialNo ++;
            // add the message to the collection:
            messages.add(msg);
        }
        
        // complete the message data:
        msg.setTopic(topicName);
        msg.setSerialNumber(msgNo);
        
        // notify listeners:
        for (NewMessageListenerProxy listener : subscriptions.getListeners())
        {
            listener.notify(msg);
        }
        
        URI msgURL = UriBuilder.fromPath("/{messageID}").build(msgNo);
        return Response.created(msgURL).build();
    }

    @GET
    public String getMessageCount()
    {
        int size;
        synchronized (messages){ size = messages.size(); }
        return "" + size;
    }

    @GET
    @Path("{msgNo:[1-9][0-9]*}")
    @Produces("application/xml")
    public ChatMessage getMessage(@PathParam("msgNo") String msgNoS) 
    {
        int msgNo = Integer.parseInt(msgNoS);
        try
        {
            ChatMessage msg;
            synchronized (messages){ msg = messages.get(msgNo - 1); } 
            return msg; 
        }
        catch(IndexOutOfBoundsException e)
        {
            throw new WebApplicationException(Status.NOT_FOUND);
        }
    }
    
    @GET
    @Path("{msgNo:[1-9][0-9]*}/replies")
    public String getRepliesToMsg(@PathParam("msgNo") String msgNoS)
    {
        int msgNo = Integer.parseInt(msgNoS);
        
        String result = "";
     
        synchronized(messages)
        {
            boolean first = true;
            for (ChatMessage msg : messages)
            {
                Integer parentMsg = msg.getParentMsg(); 
                if ( parentMsg != null && parentMsg == msgNo ) // exercise - beware parentMsg can be null
                {
                    if(!first){ result += " "; }
                    result += msg.getSerialNumber();
                    first = false;
                }
            }
        }
        return result;
    }
    

    private String topicName;
    private List<ChatMessage> messages;
    private int nextMsgSerialNo;
    private Subscriptions subscriptions;
}
