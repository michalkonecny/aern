package rest.chat.tests;

import rest.chat.messages.ChatMessage;
import rest.chat.server.NewMessageListenerProxy;

public class TestListener
{
    public static void main(String[] args)
    {
        NewMessageListenerProxy client1 = new NewMessageListenerProxy(
                "http://localhost:8080/lab6-client-model/");
        
        ChatMessage message = new ChatMessage();
        message.setSender("TestListener");
        message.setTopic("testing");
        message.setSerialNumber(1);
        message.setContent("hi");
        
        client1.notify(message);
    }
}
