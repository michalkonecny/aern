package rest.chat.server;

import rest.chat.messages.ChatMessage;

import com.sun.jersey.api.client.Client;
import com.sun.jersey.api.client.WebResource;

public class NewMessageListenerProxy
{
    private String serverURLMessages;
    private Client restClient;
    private WebResource messagesResource;

    public NewMessageListenerProxy(String serverURLBase) 
    {
        // initialise the base URL for messages:
        serverURLMessages = serverURLBase + "jaxrs/messages/";
        
        // create an object that can create resource proxies:
        restClient = new Client();
        
        // create a proxy for the server's topics collection
        messagesResource = restClient.resource(serverURLMessages);
    }
    
    public void notify(ChatMessage message)
    {
        messagesResource.post(message);
    }
}
