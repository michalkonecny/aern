package numbers.tests;

import numbers.Sample;
import numbers.Samples;

public class Test
{

    public static void main(String[] args)
    {
        Samples samples = new Samples();
        int sample1ID = samples.newSample();
        Sample sample1 = samples.getSample(sample1ID);
        sample1.addNumber(1);
        sample1.addNumber(2);
        sample1.addNumber(3);
        
        System.out.println("sample 1 = " + sample1);
        System.out.println("sample 1 sum = " + sample1.getSum());
        System.out.println("sample 1 average = " + sample1.getAverage());
        
        sample1.addNumber(4);
        System.out.println("sample 1 = " + sample1);
        System.out.println("sample 1 sum = " + sample1.getSum());
        System.out.println("sample 1 average = " + sample1.getAverage());
        
//        samples.remove(sample1ID);
    }

}
