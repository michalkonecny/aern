package numbers.resources;

import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.WebApplicationException;
import javax.ws.rs.core.Response.Status;

import numbers.Sample;
import numbers.Samples;
import numbers.repr.SampleRepr;

public class SampleResource
{
    private Sample sample;
    
    // the following two fields are there so that the sample can be deleted:
    private Samples samples;
    private int id;

    public SampleResource(Sample sample, Samples samples, int id)
    {
        super();
        this.sample = sample;
        this.samples = samples;
        this.id = id;
    }

    @GET
    public SampleRepr getRepresentation()
    {
        SampleRepr sampleRepr = new SampleRepr();

        sampleRepr.getNumber().addAll(sample.getNumbers());

        return sampleRepr;
    }

    @POST
    // as numbers are not exposed resources,
    // there is no need to return their URLs here
    public void addNumber(String numberS)
    {
        try
        {
            double number = Double.parseDouble(numberS);
            sample.addNumber(number);
        }
        catch (NumberFormatException e)
        {
            // client sent something we cannot interpret as a double number - blame them:
            throw new WebApplicationException(e, Status.BAD_REQUEST);
        }
    }
    
    @Path("sum")
    @GET
    public String getSum()
    {
        return "" + sample.getSum();
    }
    
    @Path("average")
    @GET
    public String getAverage()
    {
        return "" + sample.getAverage();
    }
    
    @DELETE
    public void remove()
    {
        samples.remove(id);
    }
}
