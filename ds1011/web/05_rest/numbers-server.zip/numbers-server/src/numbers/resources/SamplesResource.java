package numbers.resources;

import java.net.URI;

import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.WebApplicationException;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;
import javax.ws.rs.core.UriBuilder;

import numbers.Sample;
import numbers.Samples;

import com.sun.jersey.spi.resource.Singleton;

@Path("samples")
@Singleton
public class SamplesResource
{
    private Samples samples;

    public SamplesResource()
    {
        samples = new Samples();
    }

    @POST
    public Response newSample()
    {
        int id = samples.newSample();

        URI sampleURL = UriBuilder.fromPath("{sampleID}").build(id);
        return Response.created(sampleURL).build();
    }

    @Path("{sampleID}")
    public SampleResource getSample(@PathParam("sampleID") String sampleIDS)
    {
        int sampleID = Integer.parseInt(sampleIDS);
        Sample sample = samples.getSample(sampleID);
        if(sample == null)
        {
            throw new WebApplicationException(Status.NOT_FOUND);
        }
        return new SampleResource(sample, samples, sampleID);
    }
}
