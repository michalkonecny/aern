package numbers;

import java.util.Collection;
import java.util.LinkedList;
import java.util.List;


public class Sample
{
    private List<Double> numbers 
        = new LinkedList<Double>();
    
    @Override
    public String toString()
    {
        return "" + numbers;
    }

    
    public void addNumber(double number)
    {
        numbers.add(number);
    }
    
    
    public double getSum()
    {
        double result = 0;
        for(double number : numbers)
        {
            result += number;
        }
        return result;
    }
    
    
    public double getAverage()
    {
        return (getSum() / numbers.size());
    }


    public List<Double> getNumbers()
    {
        return numbers;
    }
}
