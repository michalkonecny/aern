package numbers;

import java.util.HashMap;
import java.util.Map;
import java.util.Random;

public class Samples
{
    private Map<Integer, Sample> samples = new HashMap<Integer, Sample>();

    private Random randomGen = new Random();

    public synchronized Sample getSample(int sampleID)
    {
        return samples.get(sampleID);
    }

    public synchronized int newSample()
    {
        int key;

        do
        {
            key = randomGen.nextInt();
        }
        while (samples.containsKey(key));

        samples.put(key, new Sample());

        return key;
    }

    public synchronized void remove(int sampleID)
    {
        samples.remove(sampleID);
    }
}
