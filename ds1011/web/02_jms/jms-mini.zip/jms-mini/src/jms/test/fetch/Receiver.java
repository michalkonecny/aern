package jms.test.fetch;

import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.Queue;
import javax.jms.QueueConnection;
import javax.jms.QueueConnectionFactory;
import javax.jms.QueueReceiver;
import javax.jms.QueueSession;
import javax.jms.Session;
import javax.jms.TextMessage;

import org.mr.api.jms.MantaQueueConnectionFactory;

public class Receiver
{
    private String myName;
    private QueueConnection con;
    private QueueReceiver receiver;

    public Receiver(String myName) throws JMSException
    {
        this.myName = myName;

        // create a connection object via a factory:
        QueueConnectionFactory conFactory = 
            (QueueConnectionFactory) new MantaQueueConnectionFactory();
        con = conFactory.createQueueConnection();

        // create a queue and an associated receiver:
        QueueSession session = 
            (QueueSession) con.createQueueSession(false, Session.AUTO_ACKNOWLEDGE);
        Queue receiveQueue = session.createQueue(myName);
        receiver = session.createReceiver(receiveQueue);

        // enable messaging to start:
        con.start();
    }

    public void fetchMessages() throws JMSException
    {
        while (true)
        {
            Message msg = receiver.receive();

            if (msg instanceof TextMessage)
            {
                TextMessage tmsg = (TextMessage) msg;
                System.out.println(myName + 
                        ": received: " + tmsg.getText());
            }
        }
    }

    public static void main(String[] args) throws JMSException
    {
        Receiver r = new Receiver("receiver");
        r.fetchMessages();
    }
}
