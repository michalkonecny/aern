package jms.test.listen;

import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.MessageListener;
import javax.jms.Queue;
import javax.jms.QueueConnection;
import javax.jms.QueueConnectionFactory;
import javax.jms.QueueReceiver;
import javax.jms.QueueSession;
import javax.jms.Session;
import javax.jms.TextMessage;

import org.mr.api.jms.MantaQueueConnectionFactory;

public class Receiver implements MessageListener
{
    private String myName;
    private QueueConnection con;

    public Receiver(String myName) throws JMSException
    {
        this.myName = myName;

        // create a connection object via a factory:
        QueueConnectionFactory conFactory = 
            (QueueConnectionFactory) new MantaQueueConnectionFactory();
        con = conFactory.createQueueConnection();

        // create a queue and a receiver to listen on:
        QueueSession session = 
            (QueueSession) con.createQueueSession(false, Session.AUTO_ACKNOWLEDGE);
        Queue receiveQueue = session.createQueue(myName);
        QueueReceiver receiver = session.createReceiver(receiveQueue);

        // attach itself as a listener to the queue:
        receiver.setMessageListener(this);

        // enable messaging to start:
        con.start();
    }

    // this method will be called whenever a message arrives:
    @Override
    public void onMessage(Message msg)
    {
        if (msg instanceof TextMessage)
        {
            TextMessage tmsg = (TextMessage) msg;
            try
            {
                System.out.println(myName + ": received: " + tmsg.getText());
            }
            catch (JMSException e)
            {
                throw new Error(myName
                        + ": could not extract text from a TextMessage: " + e.getMessage());
            }
        }
    }

    public static void main(String[] args) throws JMSException
    {
        new Receiver("receiver");
    }
}
