package jms.test.listen;

import javax.jms.JMSException;
import javax.jms.Queue;
import javax.jms.QueueConnection;
import javax.jms.QueueConnectionFactory;
import javax.jms.QueueSender;
import javax.jms.QueueSession;
import javax.jms.Session;
import javax.jms.TextMessage;

import org.mr.api.jms.MantaQueueConnectionFactory;

public class Sender
{
    private String myName;
    private QueueConnection con;
    private QueueSession session;

    public Sender(String myName) throws JMSException
    {
        this.myName = myName;

        // create a connection object via a factory:
        QueueConnectionFactory conFactory = 
            (QueueConnectionFactory) new MantaQueueConnectionFactory();
        con = conFactory.createQueueConnection();

        // create a session for sending messages:
        session = 
            (QueueSession) con.createQueueSession(false, Session.AUTO_ACKNOWLEDGE);
        
        // enable messaging to start:
        con.start();
    }
    
    public void sendMessage(String destination, String text) throws JMSException
    {
        Queue sendQueue = session.createQueue(destination);
        QueueSender sender = session.createSender(sendQueue);
        TextMessage tmsg = session.createTextMessage(myName + " says: " + text);
        sender.send(tmsg);
    }

    public static void main(String[] args) throws JMSException
    {
        Sender s = new Sender("sender");
        s.sendMessage("receiver", "hello!");
    }
}
