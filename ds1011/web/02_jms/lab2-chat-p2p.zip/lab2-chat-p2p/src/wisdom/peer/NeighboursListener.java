package wisdom.peer;

public interface NeighboursListener
{
    void addedNeighbour(final String peerName);
    void removedNeighbour(final String peerName);
}
