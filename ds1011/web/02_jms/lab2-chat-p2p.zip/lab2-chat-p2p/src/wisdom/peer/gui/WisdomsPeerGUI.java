package wisdom.peer.gui;

import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.HashSet;
import java.util.Set;

import javax.jms.JMSException;
import javax.swing.BorderFactory;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.SwingUtilities;

import wisdom.data.Wisdom;
import wisdom.data.WisdomsListener;
import wisdom.peer.Peer;
import wisdom.peer.NeighboursListener;

public class WisdomsPeerGUI implements NeighboursListener, WisdomsListener
{

    private static final int NEIGHBOUR_NAME_MAX_LENGTH = 20;
    private static final int WISDOM_MAX_LENGTH = 50;
    private static final int MAX_SHOW_ITEMS = 20;

    public WisdomsPeerGUI() throws UnknownHostException
    {
        super();

        getFrame().pack();

        getFrame().setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        EventQueue.invokeLater(new Runnable()
        {
            public void run()
            {
                frame.setVisible(true);
            }
        });
    }

    public void addedNeighbour(final String peerName)
    {
        neighbours.add(peerName);
        refreshNeighboursDisplay();
    }
    
    public void removedNeighbour(final String peerName)
    {
        neighbours.remove(peerName);
        refreshNeighboursDisplay();
    }
    
    private void refreshNeighboursDisplay()
    {
        String display = "";
        for(String neighbourName :  neighbours)
        {
            display += neighbourName + "\n";
        }
        
        final String displayFinal = display;
        
        if (SwingUtilities.isEventDispatchThread())
        {
            neighboursTextArea.setText(displayFinal);
        }
        else
        {
            try
            {
                SwingUtilities.invokeAndWait(new Runnable()
                {
                    public void run()
                    {
                        neighboursTextArea.setText(displayFinal);
                    }
                });
            }
            catch (Exception e)
            {
                System.out.println("Failed to udpate view of neighbours list");
                e.printStackTrace();
            }
        }
    }

    public void addedWisdom(final Wisdom wisdom)
    {
        if (SwingUtilities.isEventDispatchThread())
        {
            wisdomsTextArea.append(wisdom.getContributorPeer() + ": " + wisdom.getText() + "\n");
        }
        else
        {
            try
            {
                EventQueue.invokeAndWait(new Runnable()
                {
                    public void run()
                    {
                        wisdomsTextArea.append(wisdom.getContributorPeer() + ": " + wisdom.getText() + "\n");
                    }
                });
            }
            catch (Exception e)
            {
                System.out.println("Failed to display a new wisdom.");
                e.printStackTrace();
            }
        }
    }

    private JFrame getFrame() throws UnknownHostException
    {
        if (frame == null)
        {
            frame = new JFrame("Wisdoms Peer");
            frame.getContentPane().setLayout(new BorderLayout());
            frame.getContentPane().add(getStartPanel(), BorderLayout.NORTH);
            JPanel lowerP = new JPanel();
            lowerP.setLayout(new BoxLayout(lowerP, BoxLayout.X_AXIS));
            lowerP.add(getWisdomsPanel());
            lowerP.add(getNeighboursPanel());
            frame.getContentPane().add(lowerP, BorderLayout.CENTER);
        }
        return frame;
    }

    private JPanel getStartPanel() throws UnknownHostException
    {
        if (startPanel == null)
        {
            startPanel = new JPanel();
            startPanel.add(new JLabel("peer name ="));
            startPanel.add(getPeerNameInputField());
            startPanel.add(new JLabel("@" + getHostname()));
            startPanel.add(getStartButton());
        }
        return startPanel;
    }

    private JButton getStartButton()
    {
        if (startButton == null)
        {
            startButton = new JButton("start");
            final NeighboursListener nlistener = this;
            final WisdomsListener wlistener = this;
            startButton.addActionListener(new ActionListener()
            {
                @Override
                public void actionPerformed(ActionEvent e)
                {
                    try
                    {
                        peerName = peerNameInputField.getText() + "@"
                                + hostname;
                        enablePeer();
                        peer = new Peer(peerName, nlistener, wlistener);
                    }
                    catch (JMSException e1)
                    {
                        System.out.println("problem starting peer " + peerName);
                        e1.printStackTrace();
                        System.exit(-1);
                    }
                }
            });
        }
        return startButton;
    }

    private void enablePeer()
    {
        // change frame title:
        frame.setTitle(frame.getTitle() + " " + peerName);
        // disable start button and name input field:
        startButton.setEnabled(false);
        peerNameInputField.setEnabled(false);
        // enable add wisdom and add neighbour buttons:
        neighbourAddButton.setEnabled(true);
        wisdomAddButton.setEnabled(true);
    }

    private JTextField getPeerNameInputField()
    {
        if (peerNameInputField == null)
        {
            peerNameInputField = new JTextField(10);
        }
        return peerNameInputField;
    }

    private JPanel getWisdomsPanel()
    {
        if (wisdomsPanel == null)
        {
            wisdomsPanel = new JPanel(new BorderLayout());
            wisdomsPanel.setBorder(BorderFactory.createEtchedBorder());
            wisdomsPanel.add(new JLabel("wisdoms"), BorderLayout.NORTH);
            wisdomsPanel.add(getWisdomsTextArea(), BorderLayout.CENTER);
            JPanel lowerP = new JPanel(new BorderLayout());
            lowerP.add(getWisdomInputField(), BorderLayout.CENTER);
            lowerP.add(getWisdomAddButton(), BorderLayout.EAST);
            wisdomsPanel.add(lowerP, BorderLayout.SOUTH);
        }
        return wisdomsPanel;
    }

    private Component getWisdomAddButton()
    {
        if (wisdomAddButton == null)
        {
            wisdomAddButton = new JButton("add");
            wisdomAddButton.setEnabled(false);
            wisdomAddButton.addActionListener(new ActionListener()
            {
                public void actionPerformed(ActionEvent e)
                {
                    String text = wisdomInputField.getText();
                    wisdomInputField.setText("");
                    try
                    {
                        peer.newWisdom(text);
                    }
                    catch (JMSException e1)
                    {
                        e1.printStackTrace();
                    }
                }
            });
        }
        return wisdomAddButton;
    }

    private Component getWisdomInputField()
    {
        if (wisdomInputField == null)
        {
            wisdomInputField = new JTextField(WISDOM_MAX_LENGTH);
        }
        return wisdomInputField;
    }

    private Component getWisdomsTextArea()
    {
        if (wisdomsTextArea == null)
        {
            wisdomsTextArea = new JTextArea(MAX_SHOW_ITEMS, WISDOM_MAX_LENGTH);
            wisdomsTextArea.setEditable(false);
        }
        return wisdomsTextArea;
    }

    private JPanel getNeighboursPanel()
    {
        if (neighboursPanel == null)
        {
            neighboursPanel = new JPanel(new BorderLayout());
            neighboursPanel.setBorder(BorderFactory.createEtchedBorder());
            neighboursPanel.add(new JLabel("neighbours"), BorderLayout.NORTH);
            neighboursPanel.add(getNeighboursTextArea(), BorderLayout.CENTER);
            JPanel lowerP = new JPanel(new BorderLayout());
            lowerP.add(getNeighbourInputField(), BorderLayout.CENTER);
            lowerP.add(getNeighbourAddButton(), BorderLayout.EAST);
            neighboursPanel.add(lowerP, BorderLayout.SOUTH);
        }
        return neighboursPanel;
    }

    private JButton getNeighbourAddButton()
    {
        if (neighbourAddButton == null)
        {
            neighbourAddButton = new JButton("add");
            neighbourAddButton.setEnabled(false);
            neighbourAddButton.addActionListener(new ActionListener()
            {
                @Override
                public void actionPerformed(ActionEvent e)
                {
                    String neighbourName = neighbourInputField.getText();
                    if(peer.addNeighbour(neighbourName))
                    {
                        neighbourInputField.setText("");
                    }
                }
            });
        }
        return neighbourAddButton;
    }

    private JTextField getNeighbourInputField()
    {
        if (neighbourInputField == null)
        {
            neighbourInputField = new JTextField(NEIGHBOUR_NAME_MAX_LENGTH);
        }
        return neighbourInputField;
    }

    private JTextArea getNeighboursTextArea()
    {
        if (neighboursTextArea == null)
        {
            neighboursTextArea = new JTextArea(MAX_SHOW_ITEMS,
                    NEIGHBOUR_NAME_MAX_LENGTH);
            neighboursTextArea.setEditable(false);
        }
        return neighboursTextArea;
    }

    private String getHostname() throws UnknownHostException
    {
        if (hostname == null)
        {
            hostname = InetAddress.getLocalHost().getHostName();
        }
        return hostname;
    }

    private String hostname;
    private Peer peer;
    private String peerName;
    private Set<String> neighbours = new HashSet<String>();

    private JFrame frame;
    private JPanel startPanel;
    private JButton startButton;
    private JPanel wisdomsPanel;
    private JPanel neighboursPanel;
    private JTextField peerNameInputField;
    private JTextArea wisdomsTextArea;
    private JTextField wisdomInputField;
    private JButton wisdomAddButton;
    private JTextField neighbourInputField;
    private JTextArea neighboursTextArea;
    private JButton neighbourAddButton;

    public static void main(String[] args) throws UnknownHostException
    {
        new WisdomsPeerGUI();
    }

}
