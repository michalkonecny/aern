package wisdom.peer;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;

import javax.jms.DeliveryMode;
import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.ObjectMessage;
import javax.jms.Queue;
import javax.jms.QueueConnection;
import javax.jms.QueueConnectionFactory;
import javax.jms.QueueSender;
import javax.jms.QueueSession;
import javax.jms.Session;

import org.mr.api.jms.MantaQueueConnectionFactory;

import wisdom.data.Wisdom;
import wisdom.data.Wisdoms;
import wisdom.peer.messages.NewWisdom;

public class Neighbours
{

    public static final long SECOND = 1000; // milliseconds

    public Neighbours(String myQueueName, Wisdoms wisdoms, NeighboursListener listener)
            throws JMSException
    {
        this.myQueueName = myQueueName;
        this.wisdoms = wisdoms;
        this.listener = listener;

        neighbours = new HashMap<String, QueueSender>();

        // create a connection object via a factory:
        QueueConnectionFactory conFactory = (QueueConnectionFactory) new MantaQueueConnectionFactory();
        con = conFactory.createQueueConnection();

        sendSession = (QueueSession) con.createQueueSession(false,
                Session.AUTO_ACKNOWLEDGE);

        // enable messaging to start:
        con.start();
    }

    public synchronized void add(String neighbourQueueName) throws JMSException
    {
        if (!neighbours.containsKey(neighbourQueueName))
        {
            try
            {
                listener.addedNeighbour(neighbourQueueName);
                
                QueueSender sender = getSender(neighbourQueueName);
                // put this neighbour and its JMS sender object into the map:
                neighbours.put(neighbourQueueName, sender);
                
                // tell the new neighbour all our wisdoms:
                for (Wisdom wisdom : wisdoms)
                {
                    sendObjectTo(neighbourQueueName, new NewWisdom(myQueueName, wisdom));
                    System.out.println(myQueueName + ": sharing wisdom with new neighbour " + neighbourQueueName);
                }
            }
            catch (Exception e)
            {
                e.printStackTrace();
                System.exit(-1);
            }
        }
    }

    public synchronized boolean contains(String neighbourQueueName)
    {
        return neighbours.containsKey(neighbourQueueName);
    }

    public void sendObjectTo(String peerName, Serializable obj)
            throws JMSException
    {
        ObjectMessage msg = sendSession.createObjectMessage(obj);
        QueueSender sender = getSender(peerName);
        sender.send(msg, DeliveryMode.NON_PERSISTENT, Message.DEFAULT_PRIORITY,
                Neighbours.MESSAGE_TTL);
    }

    public synchronized void newWisdom(NewWisdom nw) throws JMSException
    {
        // update message forwarding info:
        nw.registerForward(myQueueName, neighbours.size());

        ObjectMessage msg = sendSession.createObjectMessage(nw);

        Iterator<Entry<String,QueueSender>> neighbourIter = neighbours.entrySet().iterator();
        while (neighbourIter.hasNext())
        {
            Entry<String,QueueSender>  neighbourInfo = neighbourIter.next();
            QueueSender neighbourSender = neighbourInfo.getValue();
            String neighbourName = neighbourInfo.getKey();
            neighbourSender.send(msg, DeliveryMode.NON_PERSISTENT,
                    Message.DEFAULT_PRIORITY, MESSAGE_TTL);
        }
    }

    private QueueSender getSender(String peerName) throws JMSException
    {
        Queue sendQueue = sendSession.createQueue(peerName);
        QueueSender peerSender = sendSession.createSender(sendQueue);
        return peerSender;
    }

    private String myQueueName;
    private Wisdoms wisdoms;
    private NeighboursListener listener;

    private QueueConnection con;
    private Map<String, QueueSender> neighbours;
    private QueueSession sendSession;

    private static final long MESSAGE_TTL = 6000 * SECOND;

}
