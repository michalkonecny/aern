package wisdom.peer;

import java.io.Serializable;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.ObjectMessage;
import javax.jms.Queue;
import javax.jms.QueueConnection;
import javax.jms.QueueConnectionFactory;
import javax.jms.QueueReceiver;
import javax.jms.QueueSession;
import javax.jms.Session;

import org.mr.api.jms.MantaQueueConnectionFactory;

import wisdom.data.Wisdom;
import wisdom.data.Wisdoms;
import wisdom.peer.messages.NewNeighbour;
import wisdom.peer.messages.NewWisdom;
import wisdom.peer.messages.WMessage;
import wisdom.peer.messages.WMessageResponse;

public class Dispatcher implements javax.jms.MessageListener
{

    public Dispatcher(String queueName, Neighbours neighbours, Wisdoms wisdoms)
            throws JMSException
    {
        this.myQueueName = queueName;
        this.neighbours = neighbours;
        this.wisdoms = wisdoms;
        this.responses = new HashMap<Integer, WMessageResponse>(100);

        // create a connection object via a factory:
        QueueConnectionFactory conFactory = (QueueConnectionFactory) new MantaQueueConnectionFactory();
        con = conFactory.createQueueConnection();

        // create a queue and a receiver to listen on:
        QueueSession receiveSession = (QueueSession) con.createQueueSession(
                false, Session.AUTO_ACKNOWLEDGE);
        Queue receiveQueue = receiveSession.createQueue(queueName);
        QueueReceiver receiver = receiveSession.createReceiver(receiveQueue);

        // attach itself as a listener to the queue:
        receiver.setMessageListener(this);

        // enable messaging to start:
        con.start();
    }

    /**
     * Wait for until a response to the given message
     * is registered in the responses collection.
     * If this does not happen within the given timeout,
     * stop waiting and return null.
     *   
     * @param msg message for which we want a response
     * @param timeout in milliseconds
     * @return the response message or null
     */
    public WMessageResponse awaitResponse(WMessage msg, long timeout)
    {
        WMessageResponse response = null;
        int id = msg.getId();

        Date startTime = new Date();
        Date timeoutTime = new Date(startTime.getTime() + timeout);
        long internalTimeout = timeout / 10;

        while (response == null && timeoutTime.after(new Date()))
        {
            try
            {
                synchronized (this)
                {
                    this.wait(internalTimeout);
                    response = responses.remove(id); // returns the removed
                                                     // value
                }
            }
            catch (InterruptedException e) // ignore and continue waiting
            {
            }
        }

        return response;
    }

    @Override
    public void onMessage(Message msg)
    {
        // pull out an object from the message:
        ObjectMessage omsg = (ObjectMessage) msg;
        Serializable obj;
        try
        {
            obj = omsg.getObject();
        }
        catch (JMSException e)
        {
            throw new Error("wisdom.peer.Dispatcher.onMessage: "
                    + "failed to retrieve message object: " + e.getMessage());
        }

        // investigate what sort of object came in the message:
        if (obj instanceof WMessageResponse)
        {
            WMessageResponse response = (WMessageResponse) obj;
            synchronized (this)
            {
                responses.put(response.getReplyTo(), response);
                this.notifyAll();
            }
        }
        else if (obj instanceof NewWisdom)
        {
            NewWisdom nw = (NewWisdom) obj;

            if (!wisdoms.contains(nw.getWisdom()))
            {
                System.out.println("received new wisdom: " + nw);

                processNewWisdom(nw);
            }
        }
        else if (obj instanceof NewNeighbour)
        {
            NewNeighbour nn = (NewNeighbour) obj;

            String senderName = nn.getMostRecentSenderName();

            // respond to the sender:
            try
            {
                neighbours.sendObjectTo(senderName, nn.constructResponse(myQueueName));
            }
            catch (JMSException e)
            {
                System.out.println("failed to respond to sender of NewNeighbour: "
                        + senderName);
                e.printStackTrace();
            }

            String neighbourName = nn.getNeighbourName();
            if (!neighbours.contains(neighbourName))
            {
                System.out.println("received new neighbour: " + neighbourName);

                processNewNeighbour(neighbourName);
            }
        }

    }

    private void processNewNeighbour(String neighbourName)
    {
        try
        {
            neighbours.add(neighbourName);
        }
        catch (JMSException e)
        {
            System.out.println("failed to create a queue for neighbour: "
                    + neighbourName);
            e.printStackTrace();
        }
    }

    private void processNewWisdom(NewWisdom nw)
    {
        Wisdom w = nw.getWisdom();
        int id = w.getId();

        System.out.println("storing and forwarding wisdom: " + id);

        // store this wisdom:
        wisdoms.addWisdom(w);

        // forward the whole wisdom to the neighbours:
        forwardWisdom(nw);

    }

    private void forwardWisdom(NewWisdom nw)
    {
        try
        {
            neighbours.newWisdom(nw);
        }
        catch (JMSException e)
        {
            throw new Error("wisdom.peer.Dispatcher.onMessage: "
                    + "failed to forward wisdom to the neighbours: "
                    + e.getMessage());
        }
    }

    private String myQueueName;
    private QueueConnection con;
    private Neighbours neighbours;
    private Wisdoms wisdoms;
    private Map<Integer, WMessageResponse> responses; // waiting for a new entry
                                                      // via method
                                                      // awaitResponse

}
