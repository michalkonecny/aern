package wisdom.peer.messages;

public class NewNeighbour extends WMessage
{

    public NewNeighbour(String senderName, String neighbourName)
    {
        super(senderName);
        this.neighbourName = neighbourName;
    }

    public String getNeighbourName()
    {
        return neighbourName;
    }

    @Override
    public WMessage constructResponse(String senderName)
    {
        return new NewNeighbourResponse(senderName, getId());
    }

    private String neighbourName;

    private static final long serialVersionUID = -7780798486884306968L;

}
