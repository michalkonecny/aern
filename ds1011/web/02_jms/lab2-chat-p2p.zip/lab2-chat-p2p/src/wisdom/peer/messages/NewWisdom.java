package wisdom.peer.messages;

import wisdom.data.Wisdom;

public class NewWisdom extends WMessage
{

    public NewWisdom(String senderName, Wisdom w)
    {
        super(senderName);
        this.w = w;
        
        hops = 0;
        cover = 1;
    }

    public Wisdom getWisdom()
    {
        return w;
    }

    public int getHops()
    {
        return hops;
    }

    public int getCover()
    {
        return cover;
    }

    public void registerForward(String forwardingNodeName, int count)
    {
        registerForward(forwardingNodeName);
        hops ++;
        cover *= count;
    }

    @Override
    public WMessage constructResponse(String senderName)
    {
        return new NewWisdomResponse(senderName, getId());
    }

    @Override
    public String toString()
    {
        return "NewWisdom [hops=" + hops + ", cover=" + cover + ", w=" + w
                + ", inherited = " + super.toString() + "]";
    }

    private int hops; // when forwarding, increment this
    private int cover; // when forwarding, multiply by the number of neighbours that we forward to 

    private Wisdom w;
    
    private static final long serialVersionUID = 2906550975912207433L;

}
