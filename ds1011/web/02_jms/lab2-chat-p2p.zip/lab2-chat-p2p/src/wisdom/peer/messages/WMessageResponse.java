package wisdom.peer.messages;

@SuppressWarnings("serial")
public abstract class WMessageResponse extends WMessage
{

    public WMessageResponse(String senderName, int replyTo)
    {
        super(senderName);
        this.replyTo = replyTo;
    }

    public int getReplyTo()
    {
        return replyTo;
    }

    private int replyTo;
}
