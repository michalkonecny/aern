package wisdom.peer;

import javax.jms.JMSException;

import wisdom.data.Wisdom;
import wisdom.data.Wisdoms;
import wisdom.data.WisdomsListener;
import wisdom.peer.messages.NewNeighbour;
import wisdom.peer.messages.NewNeighbourResponse;
import wisdom.peer.messages.NewWisdom;

public class Peer
{

    public Peer(String queueName) throws JMSException
    {
        this(queueName, null, null);
    }

    public Peer(String queueName, NeighboursListener nlistener,
            WisdomsListener wlistener) throws JMSException
    {
        this.queueName = queueName;
        
        if (wlistener == null)
        {
            wlistener = new WisdomsListener()
            {
                public void addedWisdom(Wisdom wisdom)
                {
                } // dummy
            };
        }
        
        if (nlistener == null)
        {
            nlistener = new NeighboursListener()
            {
                public void addedNeighbour(String peerName)
                {
                }

                public void removedNeighbour(String peerName)
                {
                }
            };
        }

        wisdoms = new Wisdoms(wlistener);
        neighbours = new Neighbours(queueName, wisdoms, nlistener);
        dispatcher = new Dispatcher(queueName, neighbours, wisdoms);
    }

    public boolean addNeighbour(String neighbourName)
    {
        if (!neighbours.contains(neighbourName))
        {
            try
            {
                // send a message to the neighbour to make the relationship
                // mutual:
                NewNeighbour nnmsg = new NewNeighbour(queueName, queueName);
                neighbours.sendObjectTo(neighbourName, nnmsg);

                // await receipt:
                NewNeighbourResponse response = (NewNeighbourResponse) dispatcher
                        .awaitResponse(nnmsg, 10 * Neighbours.SECOND);
                // check we got a response:
                if (response == null)
                {
                    System.out.println("Failed to contact peer "
                            + neighbourName);
                    return false;
                }
                else
                {
                    // success, add this guy among our neighbours:
                    neighbours.add(neighbourName);
                    return true;
                }

            }
            catch (JMSException e)
            {
                return false;
            }
        }
        else
        {
            return false;
        }
    }

    public void newWisdom(String text) throws JMSException
    {
        Wisdom wisdom = new Wisdom(text, queueName);
        wisdoms.addWisdom(wisdom);
        neighbours.newWisdom(new NewWisdom(queueName, wisdom));
    }

    private String queueName;
    private Neighbours neighbours;
    private Wisdoms wisdoms;
    private Dispatcher dispatcher;
}
