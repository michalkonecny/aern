package wisdom.peer.messages;

import java.io.Serializable;
import java.util.Random;

import sun.reflect.generics.reflectiveObjects.NotImplementedException;

@SuppressWarnings("serial")
public abstract class WMessage implements Serializable
{

    public WMessage(String senderName)
    {
        this.originalSenderName = senderName;
        this.mostRecentSenderName = senderName;
        id = randomGen.nextInt();
    }
    
    public void registerForward(String forwardingNodeName)
    {
        mostRecentSenderName = forwardingNodeName;
    }
    
    public WMessage constructResponse(String senderName)
    {
        throw new NotImplementedException();
    }
    
    public int getId()
    {
        return id;
    }

    public String getOriginalSenderName()
    {
        return originalSenderName;
    }

    public String getMostRecentSenderName()
    {
        return mostRecentSenderName;
    }

    @Override
    public String toString()
    {
        return "WMessage [id=" + id + ", originalSenderName="
                + originalSenderName + ", mostRecentSenderName="
                + mostRecentSenderName + "]";
    }

    private int id;
    
    private String originalSenderName;
    private String mostRecentSenderName;
    private static final Random randomGen = new Random();
}
