package wisdom.peer.messages;


public class NewWisdomResponse extends WMessageResponse
{
    public NewWisdomResponse(String senderName, int replyTo)
    {
        super(senderName, replyTo);
    }

    private static final long serialVersionUID = -1360590549904050835L;
}
