package wisdom.peer.messages;


public class NewNeighbourResponse extends WMessageResponse
{

    public NewNeighbourResponse(String senderName, int replyTo)
    {
        super(senderName, replyTo);
    }

    private static final long serialVersionUID = -6161083030915663537L;
}
