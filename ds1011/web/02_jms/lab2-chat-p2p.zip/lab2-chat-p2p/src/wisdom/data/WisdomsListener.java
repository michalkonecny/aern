package wisdom.data;

public interface WisdomsListener
{
    void addedWisdom(final Wisdom wisdom);
}
