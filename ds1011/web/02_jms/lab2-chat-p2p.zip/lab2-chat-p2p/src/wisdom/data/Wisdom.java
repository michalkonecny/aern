package wisdom.data;

import java.io.Serializable;
import java.util.Date;
import java.util.Random;

public class Wisdom implements Serializable
{
    private static final long serialVersionUID = -1884117804627592874L;

    public Wisdom(String text, String contributorPeer)
    {
        super();
        this.id = new Random().nextInt();
        this.creationDate = new Date();
        this.text = text;
        this.contributorPeer = contributorPeer;
    }
    
    public String getText()
    {
        return text;
    }
    
    public void setText(String text)
    {
        this.text = text;
    }
    
    public String getContributorPeer()
    {
        return contributorPeer;
    }

    public Date getCreationDate()
    {
        return creationDate;
    }

    public int getId()
    {
        return id;
    }

    @Override
    public int hashCode()
    {
        final int prime1 = 31;
        final int prime2 = 101;
        int result = prime1 + prime2 * id;
        return result;
    }

    @Override
    public boolean equals(Object obj)
    {
        if (this == obj) return true;
        if (obj == null) return false;
        if (getClass() != obj.getClass()) return false;
        Wisdom other = (Wisdom) obj;
        if (id != other.id) return false;
        return true;
    }

    @Override
    public String toString()
    {
        return "Wisdom [id=" + id + ", text=" + text + ", contributorPeer="
                + contributorPeer + ", creationDate=" + creationDate + "]";
    }

    private int id;
    private String text;
    private String contributorPeer;
    private Date creationDate;
}
