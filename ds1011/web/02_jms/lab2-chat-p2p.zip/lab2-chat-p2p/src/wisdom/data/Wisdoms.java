package wisdom.data;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

public class Wisdoms implements Iterable<Wisdom>
{

    public Wisdoms(WisdomsListener listener)
    {
        wisdomRatings = new HashMap<Wisdom, Map<String,Integer>>();
        this.listener = listener;
    }
    
    public synchronized void addWisdom(Wisdom w)
    {
        if(! wisdomRatings.containsKey(w))
        {
            try
            {
                listener.addedWisdom(w);
                wisdomRatings.put(w, new HashMap<String, Integer>());
            }
            catch (Exception e)
            {
                e.printStackTrace();
                System.exit(-1);
            }
        }
    }
    
    public synchronized boolean contains(Wisdom w)
    {
        return wisdomRatings.containsKey(w);
    }

    public synchronized void putRating(Wisdom w, String reviewerPeer, int rating)
    {
        if(wisdomRatings.containsKey(w))
        {
            wisdomRatings.get(w).put(reviewerPeer, rating);
        }
        else
        {
            throw new Error("wisdoms.putRating called with an unknown wisdom");
        }
    }
    
    public synchronized void removeRating(Wisdom w, String reviewerPeer)
    {
        if(wisdomRatings.containsKey(w))
        {
            wisdomRatings.get(w).remove(reviewerPeer);
        }
        else
        {
            throw new Error("wisdoms.removeRating called with an unknown wisdom");
        }
    }
    
    public synchronized Integer getRating(Wisdom w, String reviewerPeer)
    {
        if(wisdomRatings.containsKey(w))
        {
            return wisdomRatings.get(w).get(reviewerPeer);
        }
        else
        {
            throw new Error("wisdoms.getRating called with an unknown wisdom");
        }
    }
    
    public Iterator<Wisdom> iterator()
    {
        return wisdomRatings.keySet().iterator();
    }
    
    private Map<Wisdom, Map<String,Integer>> wisdomRatings;
    private WisdomsListener listener;
        
}
