package wisdom.tests.test002broadcast;

import javax.jms.JMSException;

import wisdom.peer.Peer;

public class RunPeerC
{
    public static void main(String[] args) throws JMSException
    {
        new Peer("peerC");
    }
}
