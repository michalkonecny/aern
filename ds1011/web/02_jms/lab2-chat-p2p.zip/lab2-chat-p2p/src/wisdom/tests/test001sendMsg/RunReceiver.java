package wisdom.tests.test001sendMsg;

import javax.jms.JMSException;

import wisdom.peer.Peer;

public class RunReceiver
{
    public static void main(String[] args) throws JMSException
    {
        new Peer("receiver");
    }
}
