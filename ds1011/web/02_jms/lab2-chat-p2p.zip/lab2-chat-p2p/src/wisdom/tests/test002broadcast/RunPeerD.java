package wisdom.tests.test002broadcast;

import javax.jms.JMSException;

import wisdom.peer.Peer;

public class RunPeerD
{
    public static void main(String[] args) throws JMSException
    {
        Peer peer = new Peer("peerD");
        peer.addNeighbour("peerB");
        peer.addNeighbour("peerC");
    }
}
