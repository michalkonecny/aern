package wisdom.tests.test002broadcast;

import javax.jms.JMSException;

import wisdom.peer.Peer;

public class RunPeerA
{
    public static void main(String[] args) throws JMSException
    {
        Peer peer = new Peer("peerA");
        peer.addNeighbour("peerB");
        peer.addNeighbour("peerC");
    }
}
