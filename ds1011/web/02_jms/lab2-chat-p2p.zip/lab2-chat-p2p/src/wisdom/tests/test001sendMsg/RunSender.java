package wisdom.tests.test001sendMsg;

import javax.jms.JMSException;

import wisdom.peer.Peer;

public class RunSender
{
    public static void main(String[] args) throws JMSException
    {
        Peer peer = new Peer("sender");
        peer.addNeighbour("receiver");
        peer.newWisdom("be good");
    }
}
