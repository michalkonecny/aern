package canvas;

import javax.swing.JPanel;
import javax.swing.JFrame;
import java.awt.Dimension;
import java.awt.Rectangle;
import java.net.MalformedURLException;
import java.rmi.NotBoundException;
import java.rmi.RemoteException;

public class FrmMain extends JFrame
{
    private static final long serialVersionUID = 1L;
    
    private JPanel jContentPane = null;
    private PnlScribble scribbleArea = null;

    public FrmMain() throws RemoteException, MalformedURLException, NotBoundException
    {
        super();
        initialize();
    }

    private void initialize() 
        throws RemoteException, MalformedURLException, NotBoundException
    {
        this.setSize(808, 629);
        this.setPreferredSize(new Dimension(800, 600));
        this.setContentPane(getJContentPane());
        this.setTitle("CS3250 - Distributed Systems");
    }

    private JPanel getJContentPane() 
        throws RemoteException, MalformedURLException, NotBoundException
    {
        if (jContentPane == null)
        {
            jContentPane = new JPanel();
            jContentPane.setLayout(null);
            jContentPane.setPreferredSize(new Dimension(800, 600));
            jContentPane.add(getScribbleArea(), null);
        }
        return jContentPane;
    }

    public PnlScribble getScribbleArea()
    {
        if (scribbleArea == null)
        {
            scribbleArea = new PnlScribble(800, 600);
            scribbleArea.setLayout(null);
            scribbleArea.setBounds(new Rectangle(0, 0, 800, 600));
            scribbleArea.repaint();
        }
        return scribbleArea;
    }
}
