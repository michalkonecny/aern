package canvas;

import java.awt.AlphaComposite;
import java.awt.Color;
import java.awt.Composite;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import javax.swing.JPanel;

public class PnlScribble extends JPanel
{
    private static final long serialVersionUID = 1L;
    
    private int xSize;
    private int ySize;
    private BufferedImage img;
    private Graphics2D gArea;

    /**
     * This is the default constructor
     */
    public PnlScribble(int x, int y)
    {
        super();
        xSize = x;
        ySize = y;
        initialize();
    }

    /**
     * This method initializes this
     * 
     * @return void
     */
    private void initialize()
    {
        this.setSize(xSize, ySize);
        img = new BufferedImage(xSize, ySize, BufferedImage.TYPE_INT_ARGB);
        gArea = (Graphics2D) img.getGraphics();
        gArea.setColor(Color.BLACK);
        gArea.fillRect(0, 0, xSize, ySize);
    }

    public void addLine(DrawableLine l)
    {

        // fade the image by drawing a semi-transparent rectangle on top
        Composite originalComposite = gArea.getComposite();
        gArea.setComposite(AlphaComposite.getInstance(AlphaComposite.SRC_OVER,
                (float) 0.01));
        gArea.setColor(Color.BLACK);
        gArea.fillRect(0, 0, xSize, ySize);
        gArea.setComposite(originalComposite);

        // draw line
        l.draw(gArea);

        repaint();
    }

    public void paintComponent(Graphics g)
    {
        g.drawImage(img, 0, 0, null);
    }

    public int getXSize()
    {
        return xSize;
    }

    public int getYSize()
    {
        return ySize;
    }
}
