package canvas;

import java.awt.Color;
import java.awt.Graphics;

import wsrpc.geom.Line;
import wsrpc.geom.Point;

/**
 * Line class
 * 
 * @author ingrambr
 * 
 */
public class DrawableLine implements java.io.Serializable
{

    private static final long serialVersionUID = 430863402403237501L;
    
    private Line line;

    public DrawableLine(Line line)
    {
        this.line = line;
    }

    public void draw(Graphics g)
    {
        g.setColor(Color.WHITE);
        Point start = line.getStart();
        Point end = line.getEnd();
        g.drawLine(start.getX(), start.getY(), end.getX(), end.getY());
    }

}
