/**
 * LineCanvasSOAPImpl.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package wsrpc.canvas;

import javax.swing.SwingUtilities;

import canvas.DrawableLine;
import canvas.FrmMain;
import canvas.PnlScribble;


import wsrpc.geom.Point;

public class LineCanvasSOAPImpl implements LineCanvas_PortType
{
    
    private static FrmMain GUI;
    
    static
    {
        try
        {
            GUI = new FrmMain();
        }
        catch (Exception e1)
        {
            e1.printStackTrace();
        }
        
        // create GUI
        SwingUtilities.invokeLater(new Runnable()
        {
            public void run()
            {
                try
                {
                    GUI.setVisible(true);
                }
                catch (Exception e)
                {
                    e.printStackTrace();
                }
            }
        });        
    }
    
    public void drawLine(wsrpc.geom.Line line) 
        throws java.rmi.RemoteException
    {
        GUI.getScribbleArea().addLine(new DrawableLine(line));        
    }

    public void getCanvasSize
        (wsrpc.geom.holders.PointHolder topLeft, 
         wsrpc.geom.holders.PointHolder botRight) 
    throws java.rmi.RemoteException
    {
        PnlScribble canvas = GUI.getScribbleArea();
        topLeft.value = new Point(0,0);
        botRight.value = new Point(canvas.getXSize(), canvas.getYSize());
    }

}
