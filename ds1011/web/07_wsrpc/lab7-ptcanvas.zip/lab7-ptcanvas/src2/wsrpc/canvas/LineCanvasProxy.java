package wsrpc.canvas;

public class LineCanvasProxy implements wsrpc.canvas.LineCanvas_PortType {
  private String _endpoint = null;
  private wsrpc.canvas.LineCanvas_PortType lineCanvas_PortType = null;
  
  public LineCanvasProxy() {
    _initLineCanvasProxy();
  }
  
  public LineCanvasProxy(String endpoint) {
    _endpoint = endpoint;
    _initLineCanvasProxy();
  }
  
  private void _initLineCanvasProxy() {
    try {
      lineCanvas_PortType = (new wsrpc.canvas.LineCanvas_ServiceLocator()).getLineCanvasSOAP();
      if (lineCanvas_PortType != null) {
        if (_endpoint != null)
          ((javax.xml.rpc.Stub)lineCanvas_PortType)._setProperty("javax.xml.rpc.service.endpoint.address", _endpoint);
        else
          _endpoint = (String)((javax.xml.rpc.Stub)lineCanvas_PortType)._getProperty("javax.xml.rpc.service.endpoint.address");
      }
      
    }
    catch (javax.xml.rpc.ServiceException serviceException) {}
  }
  
  public String getEndpoint() {
    return _endpoint;
  }
  
  public void setEndpoint(String endpoint) {
    _endpoint = endpoint;
    if (lineCanvas_PortType != null)
      ((javax.xml.rpc.Stub)lineCanvas_PortType)._setProperty("javax.xml.rpc.service.endpoint.address", _endpoint);
    
  }
  
  public wsrpc.canvas.LineCanvas_PortType getLineCanvas_PortType() {
    if (lineCanvas_PortType == null)
      _initLineCanvasProxy();
    return lineCanvas_PortType;
  }
  
  public void drawLine(wsrpc.geom.Line line) throws java.rmi.RemoteException{
    if (lineCanvas_PortType == null)
      _initLineCanvasProxy();
    lineCanvas_PortType.drawLine(line);
  }
  
  public void getCanvasSize(wsrpc.geom.holders.PointHolder topLeft, wsrpc.geom.holders.PointHolder botRight) throws java.rmi.RemoteException{
    if (lineCanvas_PortType == null)
      _initLineCanvasProxy();
    lineCanvas_PortType.getCanvasSize(topLeft, botRight);
  }
  
  
}