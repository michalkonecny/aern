/**
 * LineCanvas_PortType.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package wsrpc.canvas;

public interface LineCanvas_PortType extends java.rmi.Remote {
    public void drawLine(wsrpc.geom.Line line) throws java.rmi.RemoteException;
    public void getCanvasSize(wsrpc.geom.holders.PointHolder topLeft, wsrpc.geom.holders.PointHolder botRight) throws java.rmi.RemoteException;
}
