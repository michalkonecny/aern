/**
 * PointCanvasSOAPImpl.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package wsrpc.ptcanvas;

import wsrpc.canvas.LineCanvasProxy;
import wsrpc.geom.Line;
import wsrpc.geom.Point;

public class PointCanvasSOAPImpl implements wsrpc.ptcanvas.PointCanvas_PortType
{
    public void drawPoint(wsrpc.geom.Point point)
            throws java.rmi.RemoteException
    {
        LineCanvasProxy canvas = new LineCanvasProxy();
        
        int ptX = point.getX();
        int ptY = point.getY();
        
        Point point1 = new Point(ptX + 5, ptY + 5);
        Point point2 = new Point(ptX + 5, ptY - 5);
        Point point3 = new Point(ptX - 5, ptY - 5);
        Point point4 = new Point(ptX - 5, ptY + 5);
        
        canvas.drawLine(new Line(point1, point2));
        canvas.drawLine(new Line(point2, point3));
        canvas.drawLine(new Line(point3, point4));
        canvas.drawLine(new Line(point4, point1));
        
    }

}
