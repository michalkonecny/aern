/**
 * PointCanvas_ServiceLocator.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package wsrpc.ptcanvas;

public class PointCanvas_ServiceLocator extends org.apache.axis.client.Service implements wsrpc.ptcanvas.PointCanvas_Service {

    public PointCanvas_ServiceLocator() {
    }


    public PointCanvas_ServiceLocator(org.apache.axis.EngineConfiguration config) {
        super(config);
    }

    public PointCanvas_ServiceLocator(java.lang.String wsdlLoc, javax.xml.namespace.QName sName) throws javax.xml.rpc.ServiceException {
        super(wsdlLoc, sName);
    }

    // Use to get a proxy class for PointCanvasSOAP
    private java.lang.String PointCanvasSOAP_address = "http://www.example.org/";

    public java.lang.String getPointCanvasSOAPAddress() {
        return PointCanvasSOAP_address;
    }

    // The WSDD service name defaults to the port name.
    private java.lang.String PointCanvasSOAPWSDDServiceName = "PointCanvasSOAP";

    public java.lang.String getPointCanvasSOAPWSDDServiceName() {
        return PointCanvasSOAPWSDDServiceName;
    }

    public void setPointCanvasSOAPWSDDServiceName(java.lang.String name) {
        PointCanvasSOAPWSDDServiceName = name;
    }

    public wsrpc.ptcanvas.PointCanvas_PortType getPointCanvasSOAP() throws javax.xml.rpc.ServiceException {
       java.net.URL endpoint;
        try {
            endpoint = new java.net.URL(PointCanvasSOAP_address);
        }
        catch (java.net.MalformedURLException e) {
            throw new javax.xml.rpc.ServiceException(e);
        }
        return getPointCanvasSOAP(endpoint);
    }

    public wsrpc.ptcanvas.PointCanvas_PortType getPointCanvasSOAP(java.net.URL portAddress) throws javax.xml.rpc.ServiceException {
        try {
            wsrpc.ptcanvas.PointCanvasSOAPStub _stub = new wsrpc.ptcanvas.PointCanvasSOAPStub(portAddress, this);
            _stub.setPortName(getPointCanvasSOAPWSDDServiceName());
            return _stub;
        }
        catch (org.apache.axis.AxisFault e) {
            return null;
        }
    }

    public void setPointCanvasSOAPEndpointAddress(java.lang.String address) {
        PointCanvasSOAP_address = address;
    }

    /**
     * For the given interface, get the stub implementation.
     * If this service has no port for the given interface,
     * then ServiceException is thrown.
     */
    public java.rmi.Remote getPort(Class serviceEndpointInterface) throws javax.xml.rpc.ServiceException {
        try {
            if (wsrpc.ptcanvas.PointCanvas_PortType.class.isAssignableFrom(serviceEndpointInterface)) {
                wsrpc.ptcanvas.PointCanvasSOAPStub _stub = new wsrpc.ptcanvas.PointCanvasSOAPStub(new java.net.URL(PointCanvasSOAP_address), this);
                _stub.setPortName(getPointCanvasSOAPWSDDServiceName());
                return _stub;
            }
        }
        catch (java.lang.Throwable t) {
            throw new javax.xml.rpc.ServiceException(t);
        }
        throw new javax.xml.rpc.ServiceException("There is no stub implementation for the interface:  " + (serviceEndpointInterface == null ? "null" : serviceEndpointInterface.getName()));
    }

    /**
     * For the given interface, get the stub implementation.
     * If this service has no port for the given interface,
     * then ServiceException is thrown.
     */
    public java.rmi.Remote getPort(javax.xml.namespace.QName portName, Class serviceEndpointInterface) throws javax.xml.rpc.ServiceException {
        if (portName == null) {
            return getPort(serviceEndpointInterface);
        }
        java.lang.String inputPortName = portName.getLocalPart();
        if ("PointCanvasSOAP".equals(inputPortName)) {
            return getPointCanvasSOAP();
        }
        else  {
            java.rmi.Remote _stub = getPort(serviceEndpointInterface);
            ((org.apache.axis.client.Stub) _stub).setPortName(portName);
            return _stub;
        }
    }

    public javax.xml.namespace.QName getServiceName() {
        return new javax.xml.namespace.QName("ptcanvas.wsrpc", "PointCanvas");
    }

    private java.util.HashSet ports = null;

    public java.util.Iterator getPorts() {
        if (ports == null) {
            ports = new java.util.HashSet();
            ports.add(new javax.xml.namespace.QName("ptcanvas.wsrpc", "PointCanvasSOAP"));
        }
        return ports.iterator();
    }

    /**
    * Set the endpoint address for the specified port name.
    */
    public void setEndpointAddress(java.lang.String portName, java.lang.String address) throws javax.xml.rpc.ServiceException {
        
if ("PointCanvasSOAP".equals(portName)) {
            setPointCanvasSOAPEndpointAddress(address);
        }
        else 
{ // Unknown Port Name
            throw new javax.xml.rpc.ServiceException(" Cannot set Endpoint Address for Unknown Port" + portName);
        }
    }

    /**
    * Set the endpoint address for the specified port name.
    */
    public void setEndpointAddress(javax.xml.namespace.QName portName, java.lang.String address) throws javax.xml.rpc.ServiceException {
        setEndpointAddress(portName.getLocalPart(), address);
    }

}
