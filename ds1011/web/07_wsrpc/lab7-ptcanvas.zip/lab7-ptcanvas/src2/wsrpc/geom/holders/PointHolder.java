/**
 * PointHolder.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package wsrpc.geom.holders;

public final class PointHolder implements javax.xml.rpc.holders.Holder {
    public wsrpc.geom.Point value;

    public PointHolder() {
    }

    public PointHolder(wsrpc.geom.Point value) {
        this.value = value;
    }

}
