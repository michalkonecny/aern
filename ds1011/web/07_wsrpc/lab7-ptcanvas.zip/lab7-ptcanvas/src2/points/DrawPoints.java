package points;

import java.rmi.RemoteException;

import wsrpc.canvas.LineCanvasProxy;
import wsrpc.geom.Line;
import wsrpc.geom.Point;
import wsrpc.geom.holders.PointHolder;

public class DrawPoints
{
    public static void main(String[] args) throws RemoteException
    {
        LineCanvasProxy canvas = new LineCanvasProxy();
        
        PointHolder topLeft = new PointHolder();
        PointHolder botRight = new PointHolder();
        canvas.getCanvasSize(topLeft, botRight);
        
        int centre_X = (topLeft.value.getX() + botRight.value.getX())/2;
        int centre_Y = (topLeft.value.getY() + botRight.value.getY())/2;
        
        Point point1 = new Point(centre_X + 5, centre_Y + 5);
        Point point2 = new Point(centre_X + 5, centre_Y - 5);
        Point point3 = new Point(centre_X - 5, centre_Y - 5);
        Point point4 = new Point(centre_X - 5, centre_Y + 5);
        
        canvas.drawLine(new Line(point1, point2));
        canvas.drawLine(new Line(point2, point3));
        canvas.drawLine(new Line(point3, point4));
        canvas.drawLine(new Line(point4, point1));
        
    }
}
