package wisdoms.test;

import wisdoms.Wisdom;
import wisdoms.Wisdoms;

public class Test1
{
    public static void main(String[] args)
    {
        Wisdoms wisdoms = new Wisdoms();

        int ae1 = wisdoms.addWisdom(new Wisdom("mk", "Albert Einstein",
                "Things should be made as simple as possible, but not any simpler."));

        int ae2 = wisdoms.addWisdom(new Wisdom("mk", "Albert Einstein",
                "Two things are infinite: the universe and human stupidity; and I'm not sure about the universe."));

        int mt1 = wisdoms.addWisdom(new Wisdom("mk", "Mother Teresa",
                "Be faithful in small things because it is in them that your strength lies."));
        
        wisdoms.getWisdomRatings(ae1).addRating(5);
        wisdoms.getWisdomRatings(ae1).addRating(4);
        wisdoms.getWisdomRatings(ae1).addRating(5);
        wisdoms.getWisdomRatings(ae1).addRating(3);
        wisdoms.getWisdomRatings(ae1).addRating(5);
        
        wisdoms.getWisdomRatings(ae2).addRating(5);
        wisdoms.getWisdomRatings(ae2).addRating(1);
        wisdoms.getWisdomRatings(ae2).addRating(4);
        wisdoms.getWisdomRatings(ae2).addRating(2);
        
        System.out.printf("wisdom ae1 = %s", wisdoms.getWisdom(ae1));
        System.out.printf("wisdom ae1 ratings summary:\n %s\n\n", wisdoms.getWisdomRatings(ae1).getRatingSummary());

        System.out.printf("wisdom ae2 = %s", wisdoms.getWisdom(ae2));
        System.out.printf("wisdom ae2 ratings summary:\n %s\n\n", wisdoms.getWisdomRatings(ae2).getRatingSummary());

        System.out.printf("wisdom mt1 = %s", wisdoms.getWisdom(mt1));
        System.out.printf("wisdom mt1 ratings summary:\n %s\n\n", wisdoms.getWisdomRatings(mt1).getRatingSummary());
        
    }
}
