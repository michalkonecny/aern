package wisdoms;

import java.util.HashMap;
import java.util.Map;

/**
 * A collection of wisdoms and their associated ratings.
 */
public class Wisdoms
{
    /**
     * Create a new empty collection of wisdoms.
     */
    public Wisdoms()
    {
        wisdomRatings = new HashMap<Integer, Ratings<Wisdom>>();
    }

    /**
     * n is an upper bound on the wisdom IDs stored in the collection.
     * The first wisdom is assigned id 1, then 2 etc.  This method returns
     * the last one used, thus all wisdoms stored have IDs between 1 and n.
     * Beware that some of these wisdoms may have been deleted. 
     * 
     * @return n the highest wisdom numeric identifier ever assigned by this collection
     */
    public synchronized int getHighestID()
    {
        return highestID;
    }

    /**
     * Add a wisdom to the collection.
     *  
     * @param w the wisdom to add
     * @return the id of the wisdom in this collection
     */
    public synchronized int addWisdom(Wisdom w)
    {
        highestID = highestID + 1;
        wisdomRatings.put(highestID, new Ratings<Wisdom>(w));
        return highestID;
    }

    /**
     * Return the wisdom with the given id.
     * If there is no such wisdom in the collection, throw a runtime exception.
     *  
     * @param id of wisdom to look up
     * @return the wisdom with the given id
     */
    public Wisdom getWisdom(int id)
    {
        Ratings<Wisdom> ratings;
        
        synchronized(this)
        {
            // lookup a wisdom ratings with the given id:
            ratings = wisdomRatings.get(id);
        }

        // check it exists:
        if (ratings == null) 
        { 
            throw new RuntimeException(
                "getWisdom: called with non-existent id " + id); 
        }

        return ratings.getRatedObject();
    }

    /**
     * Remove the wisdom with the given id from the collection.
     * Do not fail if the wisdom does not exist - return false instead.
     * 
     * @param id of wisdom to remove
     * @return true if the removal is successful, false otherwise
     */
    public boolean removeWisdom(int id)
    {
        Ratings<Wisdom> removedWisdomRatings;
        synchronized(this)
        {
            removedWisdomRatings = wisdomRatings.remove(id);
        }

        // let the caller know whether a removal occurred:
        if (removedWisdomRatings == null)
        {
            return false;
        }
        else
        {
            return true;
        }
    }

    /**
     * Return a ratings collection for the wisdom with the given id.
     * If there is no wisdom with this id, throw a runtime exception.
     * 
     * @param id of wisdom to lookup
     * @return all ratings assigned to this wisdom so far
     */
    public Ratings<Wisdom> getWisdomRatings(int id)
    {
        // lookup a wisdom ratings with the given id:
        Ratings<Wisdom> ratings; 
        synchronized(this)
        {
            ratings = wisdomRatings.get(id);
        }

        // check it exists:
        if (ratings == null) 
        { 
            throw new RuntimeException(
                "getWisdomRatings: called with non-existent id " + id); 
        }

        return ratings;
    }

    /**
     * This collection is indexed by the wisdom IDs and
     * should always contain only keys in the range 1..highestID.
     * As the elements may be removed, not all keys in the range
     * 1..highestID will necessarily be present. 
     */
    private Map<Integer, Ratings<Wisdom>> wisdomRatings;
    private int highestID = 0;
}
