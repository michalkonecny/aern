package wisdoms;

import java.util.HashMap;
import java.util.Map;

/**
 * Ratings related to some object of type T.
 * Also able to calculate basic statistical measures for the collection. 
 * 
 * @param <T> the type of object rated
 */
public class Ratings<T>
{
    /**
     * Create a new empty collection of ratings for the given object.
     * 
     * @param ratedObject the object to store ratings for
     */
    public Ratings(T ratedObject)
    {
        super();
        this.ratedObject = ratedObject;
        this.ratings = new HashMap<Integer, Integer>(); 
    }
    
    public T getRatedObject()
    {
        return ratedObject;
    }

    public synchronized int getHighestID()
    {
        return highestID;
    }
    
    /**
     * Add a new rating for the object.
     * 
     * @param rating an integer between 1 and 5
     * @return the id of the rating in this rating collection
     */
    public int addRating(int rating)
    {
        // check the rating is in the permitted range:
        checkRatingRange(rating, "addRating");
        
        synchronized (this)
        {
            highestID = highestID + 1;
            ratings.put(highestID, rating);
            return highestID;
        }
    }
    
    /**
     * Return a rating with this id.
     * If such rating does not exist, throw a runtime exception.
     * 
     * @param id of a rating to look up.
     * @return the rating
     */
    public int getRating(int id)
    {
        return getRating(id, "getRating");
    }
    
    /**
     * Change a previously given rating.  If no such rating
     * exists, throw a runtime exception. 
     * 
     * @param id of rating to adjust
     * @param rating new rating value between 1 and 5 
     */
    public synchronized void changeRating(int id, int rating)
    {
        // check the rating exists:
        getRating(id, "changeRating");
        
        // check the rating is in the permitted range:
        checkRatingRange(rating, "changeRating");
        
        // finally, change the rating:
        ratings.put(id, rating);
    }
    
    /**
     * Calculate basic statistical measures for the collection of ratings.
     * @return a rating summary object for this collection
     */
    public RatingSummary getRatingSummary()
    {
        // check there is at least one rating:
        if(ratings.isEmpty())
        {
            return new RatingSummary();
        }
        
        // first work out the size, bounds and mean:
        int count = 0;
        int sum = 0;
        int highestRating = 0;
        int lowestRating = 5;
        for(int rating : ratings.values())
        {
            count++;
            sum += rating;
            if(rating > highestRating) { highestRating = rating; }
            if(rating < lowestRating) { lowestRating = rating; }
        }
        double mean = ((double)sum)/count;
        
        // now work out the standard deviation:
        double squareDifferenceSum = 0;
        for(int rating : ratings.values())
        {
            double difference = rating - mean;
            squareDifferenceSum += difference * difference;
        }
        double standardDeviation =
            Math.sqrt(squareDifferenceSum / count);
        
        return new RatingSummary(count, lowestRating, highestRating, mean, standardDeviation);
    }
    
    /**
     * Helper method to look up a rating.  If the rating does not exist,
     * throw a runtime exception mentioning the given context in the
     * exception message.
     * 
     * @param id of rating to look up
     * @param contextDescription to mention in exception messages to identify context of error 
     * @return the rating value
     */
    private int getRating(int id, String contextDescription)
    {
        Integer rating;
        synchronized(this)
        {
            rating = ratings.get(id);
        }
        
        if(rating == null)
        {
            throw new RuntimeException(contextDescription 
                    + ": no rating with id " + id);
        }
        
        return rating;
    }
    
    /**
     * Check that a given rating value is in the correct range 1..5.
     * If not, throw a runtime exception, mentioning the given context description.
     * 
     * @param rating to check whether valid or not
     * @param contextDescription to mention in exception messages to identify context of error 
     */
    private void checkRatingRange(int rating, String contextDescription)
    {
        if(rating < 1 || rating > 5)
        {
            throw new 
                RuntimeException(contextDescription + ": rating " + rating 
                                 + " out of range 1..5");
        }
    }

    private T ratedObject;
    
    /**
     * This collection is indexed by the rating IDs and
     * its key collection should always be equal to the range 1..highestID.
     */
    private Map<Integer, Integer> ratings;
    private int highestID = 0;
}
