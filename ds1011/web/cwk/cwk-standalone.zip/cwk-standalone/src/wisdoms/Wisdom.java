package wisdoms;

/**
 * Entity class holding a wise saying in English, Spanish and Catalan
 * as well as the names of its author and contributor to the database.
 */
public class Wisdom
{
    
    public Wisdom(String contributor, String author, String text_en)
    {
        this.contributor = contributor;
        this.author = author;
        this.text_en = text_en;
        this.text_es = "Spanish translation not supported yet";
        this.text_ca = "Catalan translation not supported yet";
    }
    
    public String getContributor()
    {
        return contributor;
    }
    
    public String getAuthor()
    {
        return author;
    }
    
    public String getTextEnglish()
    {
        return text_en;
    }

    public String getTextCatalan()
    {
        return text_ca;
    }

    public String getTextSpanish()
    {
        return text_es;
    }

    @Override
    public String toString()
    {
        String result = "";
        result += "Wisdom:\n";
        result += " contributor = " + contributor + "\n";
        result += " author= " + author + "\n";
        result += " text_en= " + text_en + "\n";
        result += " text_ca= " + text_ca + "\n";
        result += " text_es= " + text_es + "\n";
        return result;
    }



    private String contributor;
    private String author;
    private String text_en;
    private String text_ca;
    private String text_es;
}
