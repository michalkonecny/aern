package wisdoms;

/**
 * An entity class holding various numerical values
 * derived from a collection of numerical reviews.
 */
public class RatingSummary
{
    /**
     * Create a summary of an empty ratings sample.
     */
    public RatingSummary()
    {
        this.sampleSize = 0;
    }
    
    /**
     * Create a fully populated ratings summary object.
     * 
     * @param sampleSize
     * @param lowestRating
     * @param highestRating
     * @param mean
     * @param standardDeviation
     */
    public RatingSummary(int sampleSize, int lowestRating, int highestRating,
            double mean, double standardDeviation)
    {
        this.sampleSize = sampleSize;
        this.lowestRating = lowestRating;
        this.highestRating = highestRating;
        this.mean = mean;
        this.standardDeviation = standardDeviation;
    }

    public boolean isValid()
    {
        return sampleSize > 0;
    }
    
    public int getSampleSize()
    {
        return sampleSize;
    }

    public int getLowestRating()
    {
        return lowestRating;
    }

    public int getHighestRating()
    {
        return highestRating;
    }

    public double getMean()
    {
        return mean;
    }

    public double getStandardDeviation()
    {
        return standardDeviation;
    }

    @Override
    public String toString()
    {
        if(isValid())
        {
            return String.format("%d ratings ranging between %d and %d with mean %.3f and standard deviation %.3f", 
                    sampleSize, lowestRating, highestRating, mean, standardDeviation);
        }
        else
        {
            return "no ratings";
        }
    }

    private int sampleSize;
    private int lowestRating;
    private int highestRating;
    private double mean;
    private double standardDeviation;
}
