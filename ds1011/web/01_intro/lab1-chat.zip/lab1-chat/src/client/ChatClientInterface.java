package client;

import java.rmi.Remote;
import java.rmi.RemoteException;

public interface ChatClientInterface extends Remote
{
    void newMessage(Object msg) throws RemoteException;

    String getName() throws RemoteException;
}
