package client;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.InetAddress;
import java.net.MalformedURLException;
import java.net.UnknownHostException;
import java.rmi.Naming;
import java.rmi.NotBoundException;
import java.rmi.RMISecurityManager;
import java.rmi.RemoteException;
import java.rmi.server.ServerNotActiveException;
import java.rmi.server.UnicastRemoteObject;

import server.ChatServerInterface;
import messages.Message;

public class ChatClient 
    extends UnicastRemoteObject 
    implements ChatClientInterface
{
    private static final long serialVersionUID = -6438525179496519739L;
    private ChatServerInterface server;
    private String clientname;

    public ChatClient(String name, int port, String serverHost, String serverName) 
        throws RemoteException, MalformedURLException, 
               NotBoundException, UnknownHostException
    {
        super(port);
        
        clientname = name + "@" + InetAddress.getLocalHost().getHostName();
        
        // locate the server:
        server = 
            (ChatServerInterface) 
                Naming.lookup("rmi://" + serverHost + "/" + serverName);
        
        // subscribe to the server:
        server.subscribe(this);
    }

    private void sendMessage(String msgContent) 
        throws RemoteException, ServerNotActiveException
    {
        server.sendMessage(new Message(clientname, msgContent));
    }

    private void unsubscribe() throws RemoteException
    {
        server.unsubscribe(this);        
    }

    public synchronized void newMessage(Object msg) throws RemoteException
    {
        System.out.printf("New message:\n%s\n", msg.toString());
    }

    public String getName() throws RemoteException
    {
        return clientname;
    }

    public static void main(String[] args)
    {
        String serverName = ChatServerInterface.DEFAULT_SERVER_NAME;
        
        // determine client name from command-line argument:
        String name = "client"; // default name
        if (args.length > 0) { name = args[0]; }
        
        // determine client name from command-line argument:
        String serverHost = "localhost"; // by default look for server locally
        if (args.length > 1) { serverHost = args[1]; }
        
        // determine client name from command-line argument:
        int port = 51000; // by default look for server locally
        if (args.length > 2) { port = Integer.parseInt(args[2]); }
        
        // start security manager to allow and monitor connections:
        System.setSecurityManager(new RMISecurityManager());

        try
        {
            // create a client object that will act as a listener:
            ChatClient chatClient = 
                new ChatClient(name, port, serverHost, serverName);
            // keep asking user for messages:
            BufferedReader stdin = 
                new BufferedReader(new InputStreamReader(System.in));
            String msgContent;
            while(true)
            {   
                // get a message from user:
                System.out.printf("msg: ");
                msgContent = stdin.readLine();
                
                // check whether the user wants to quit:
                if(msgContent != null && (! msgContent.equals("q")))
                {
                    // no, user gave a message, send it out:
                    chatClient.sendMessage(msgContent);
                }
                else
                {
                    // unsubscribe and quit:
                    chatClient.unsubscribe();
                    System.exit(0);
                }
            }
        }
        catch (Exception e)
        {
            e.printStackTrace();
            System.exit(0);
        }
    }
}
