package server;

import java.rmi.Remote;
import java.rmi.RemoteException;

import client.ChatClientInterface;

public interface ChatServerInterface extends Remote
{
    public static final String DEFAULT_SERVER_NAME = "CS3250ChatServer";
    
    void subscribe(ChatClientInterface client) throws RemoteException;
    
    void unsubscribe(ChatClientInterface client) throws RemoteException;
    
    void sendMessage(Object msg) throws RemoteException;
}